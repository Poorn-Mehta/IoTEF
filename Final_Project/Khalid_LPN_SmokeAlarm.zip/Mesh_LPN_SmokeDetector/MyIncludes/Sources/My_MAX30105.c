/*
 * My_MAX30105.c
 *
 *  Created on: Dec 2, 2018
 *      Author: Khalid AlAwadhi
 */
#include "MyIncludes/Headers/My_MAX30105.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "em_i2c.h"
#include "platform/emdrv/sleep/inc/sleep.h"

#include "em_cmu.h"
#include "em_gpio.h"



/* Global variable flags */
volatile uint8_t ACK_INT = 0;
volatile uint8_t RX_INT = 0;
volatile uint8_t RX_Data = 0;


/* Internal Sensor Defines */
#define MAX30105_ADDRESS						0x57	//7-bit I2C Address
#define MAX30105_REG_PARTID						0xFF	//Register address

//Configuration Registers
#define MAX30105_MODECONFIG						0x09U
#define MAX30105_RESET_MASK 					0xBFU
#define MAX30105_RESET							0x40U

//FIFO CONFIG
#define MAX30105_FIFOCONFIG						0x08U

//SAMPLE
#define MAX30105_SAMPLEAVG_MASK 				(uint8_t)~0b11100000
#define MAX30105_SAMPLEAVG_1					0x00U
#define MAX30105_SAMPLEAVG_2					0x20U
#define MAX30105_SAMPLEAVG_4					0x40U
#define MAX30105_SAMPLEAVG_8					0x60U
#define MAX30105_SAMPLEAVG_16 					0x80U
#define MAX30105_SAMPLEAVG_32					0xA0U

//ROLLOVER
#define MAX30105_ROLLOVER_MASK					0xEFU
#define MAX30105_ROLLOVER_ENABLE				0x10U
#define MAX30105_ROLLOVER_DISABLE				0x00U

//LED
#define MAX30105_MODE_MASK						0xF8U
#define MAX30105_MODE_REDONLY					0x02U
#define MAX30105_MODE_REDIRONLY					0x03U
#define MAX30105_MODE_MULTILED					0x07U

//ADC
#define MAX30105_ADCRANGE_MASK					0x9FU
#define MAX30105_ADCRANGE_2048					0x00U
#define MAX30105_ADCRANGE_4096					0x20U
#define MAX30105_ADCRANGE_8192					0x40U
#define MAX30105_ADCRANGE_16384					0x60U

//PARTICLE CONFIG
#define MAX30105_PARTICLECONFIG					0x0AU

//SAMPLE RATE
#define MAX30105_SAMPLERATE_MASK				0xE3U
#define MAX30105_SAMPLERATE_50					0x00U
#define MAX30105_SAMPLERATE_100					0x04U
#define MAX30105_SAMPLERATE_200					0x08U
#define MAX30105_SAMPLERATE_400					0x0CU
#define MAX30105_SAMPLERATE_800					0x10U
#define MAX30105_SAMPLERATE_1000				0x14U
#define MAX30105_SAMPLERATE_1600				0x18U
#define MAX30105_SAMPLERATE_3200				0x1CU

//PULSE WIDTH
#define MAX30105_PULSEWIDTH_MASK				0xFCU
#define MAX30105_PULSEWIDTH_69					0x00U
#define MAX30105_PULSEWIDTH_118					0x01U
#define MAX30105_PULSEWIDTH_215					0x02U
#define MAX30105_PULSEWIDTH_411					0x03U

#define MAX30105_LED1_PULSEAMP					0x0CU
#define MAX30105_LED2_PULSEAMP					0x0DU
#define MAX30105_LED3_PULSEAMP					0x0EU
#define MAX30105_LED_PROX_AMP					0x10U

//SLOT
#define MAX30105_MULTILEDCONFIG1				0x11U
#define MAX30105_MULTILEDCONFIG2				0x12U
#define MAX30105_SLOT1_MASK						0xF8U
#define MAX30105_SLOT2_MASK						0x8FU
#define SLOT_RED_LED							0x01U
#define SLOT_IR_LED								0x02U

//FIFO Registers
#define MAX30105_FIFOWRITEPTR					0x04U
#define MAX30105_FIFOOVERFLOW					0x05U
#define MAX30105_FIFOREADPTR					0x06U
#define MAX30105_FIFODATA						0x07U




void MAX30105_I2C_Setup()
{
	/* Enables needed clocks */
	CMU_ClockEnable(cmuClock_HFPER, true);
	CMU_ClockEnable(cmuClock_I2C0, true);

	/* Define and Init I2C0 */
	I2C_Init_TypeDef I2CInit =
	{
		false,                 /* Disable when initialization done. */
	    true,                  /* Set to master mode. */
	    0,                     /* Use currently configured reference clock. */
	    I2C_FREQ_STANDARD_MAX, /* Set to standard rate assuring being within I2C specification */
	    i2cClockHLRStandard    /* Set to use 4:4 low/high duty cycle. */
	};

	/* SCL (PC10) and SDA (PC11) */
	GPIO_PinModeSet(gpioPortC, 10, gpioModeWiredAnd, 1);	//SCL
	GPIO_PinModeSet(gpioPortC, 11, gpioModeWiredAnd, 1);	//SDA

	/* Exit the busy state.  The I2C0 will be in this state out of RESET */
	if (I2C0->STATE & I2C_STATE_BUSY)
	{
		I2C0->CMD = I2C_CMD_ABORT;
	}

	/* Clearing the I2C SCL */
	for (uint8_t i = 0; i < 9; i++)
	{
		GPIO_PinOutClear(gpioPortC, 10);
		GPIO_PinOutSet(gpioPortC, 10);
	}

	/* Initializing the I2C */
	I2C_Init(I2C0, &I2CInit);

	/* Route I2C */
	I2C0->ROUTELOC0 = I2C_ROUTELOC0_SCLLOC_LOC14 | I2C_ROUTELOC0_SDALOC_LOC16;
	I2C0->ROUTEPEN = I2C_ROUTEPEN_SCLPEN | I2C_ROUTEPEN_SDAPEN;

	/* Clear and enable interrupt from I2C module */
	NVIC_ClearPendingIRQ(I2C0_IRQn);

	//ACK
	I2C0->IFC = I2C_IFC_ACK;			//Clear ACK
	I2C_IntEnable(I2C0, I2C_IF_ACK);

	//RX
	I2C_IntEnable(I2C0, I2C_IF_RXDATAV);

	NVIC_EnableIRQ(I2C0_IRQn);
	I2C_Enable(I2C0, true);
}



void MAX30105_Sensor_Setup(uint8_t Sensor_Sample_Average, uint8_t ADC_Range, uint8_t Sample_Rate,
		                   uint8_t Pulse_Width, uint8_t Power_Level)
{
	/* Reset all configuration, threshold, and data registers to POR values */
	MAX30105_BITMask_Set(MAX30105_MODECONFIG, MAX30105_RESET_MASK, MAX30105_RESET);

	/* Poll until reset is complete */
	while(1)
	{
		uint8_t Response = MAX30105_I2C_ReadReg(MAX30105_MODECONFIG);

		if( (Response & MAX30105_RESET) == 0)
		{
			break; //Clear and reset complete
		}
	}


	/* Samples to average: */
	switch (Sensor_Sample_Average)
	{
		case 1:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_1);
			break;

		case 2:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_2);
			break;

		case 3:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_4);
			break;

		case 4:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_8);
			break;

		case 5:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_16);
			break;

		case 6:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_32);
			break;

		default:
			MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_SAMPLEAVG_MASK, MAX30105_SAMPLEAVG_4);
			break;
	}

	/* Enable roll over if FIFO overflows */
	MAX30105_BITMask_Set(MAX30105_FIFOCONFIG, MAX30105_ROLLOVER_MASK, MAX30105_ROLLOVER_ENABLE);


	/* Mode Configuration: only RED LED for now */
	MAX30105_BITMask_Set(MAX30105_MODECONFIG, MAX30105_MODE_MASK, MAX30105_MODE_REDONLY);

	/* Set ADC Range */
	switch (ADC_Range)
	{
		case 1:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_ADCRANGE_MASK, MAX30105_ADCRANGE_2048);
			break;

		case 2:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_ADCRANGE_MASK, MAX30105_ADCRANGE_4096);
			break;

		case 3:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_ADCRANGE_MASK, MAX30105_ADCRANGE_8192);
			break;

		case 4:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_ADCRANGE_MASK, MAX30105_ADCRANGE_16384);
			break;

		default:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_ADCRANGE_MASK, MAX30105_ADCRANGE_2048);
			break;
	}

	/* Set Sample Rate */
	switch (Sample_Rate)
	{
		case 1:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_50);
			break;

		case 2:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_100);
			break;

		case 3:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_200);
			break;

		case 4:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_400);
			break;

		case 5:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_800);
			break;

		case 6:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_1000);
			break;

		case 7:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_1600);
			break;

		case 8:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_3200);
			break;

		default:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_SAMPLERATE_MASK, MAX30105_SAMPLERATE_50);
			break;
	}


	/* Set Pulse Width */
	switch (Pulse_Width)
	{
		case 1:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_PULSEWIDTH_MASK, MAX30105_PULSEWIDTH_69);
			break;

		case 2:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_PULSEWIDTH_MASK, MAX30105_PULSEWIDTH_118);
			break;

		case 3:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_PULSEWIDTH_MASK, MAX30105_PULSEWIDTH_215);
			break;

		case 4:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_PULSEWIDTH_MASK, MAX30105_PULSEWIDTH_411);
			break;

		default:
			MAX30105_BITMask_Set(MAX30105_PARTICLECONFIG, MAX30105_PULSEWIDTH_MASK, MAX30105_PULSEWIDTH_69);
			break;
	}


	/* Set Power Level */
	MAX30105_I2C_WriteReg(MAX30105_LED1_PULSEAMP, Power_Level);

	/* Enable RED LED Slot */
	MAX30105_BITMask_Set(MAX30105_MULTILEDCONFIG1, MAX30105_SLOT1_MASK, SLOT_RED_LED);


	/* Clear and reset FIFO as the datasheet recommends it */
	MAX30105_I2C_WriteReg(MAX30105_FIFOWRITEPTR, 0);
	MAX30105_I2C_WriteReg(MAX30105_FIFOOVERFLOW, 0);
	MAX30105_I2C_WriteReg(MAX30105_FIFOREADPTR, 0);
}




void MAX30105_BITMask_Set(uint8_t Register, uint8_t Mask, uint8_t Option)
{
	/* Gets the current register contents */
	uint8_t OriginalContents = MAX30105_I2C_ReadReg(Register);

	/* Zero-out the portions of the register we're interested in changing */
	OriginalContents = OriginalContents & Mask;

	/* Write new contents */
	MAX30105_I2C_WriteReg(Register, OriginalContents | Option);
}




uint8_t MAX30105_I2C_ReadReg(uint8_t Register)
{
	uint8_t Data;

	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 0;		//SlaveAddr + W

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->TXDATA = Register;						//Send Register Byte

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag


	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 1;		//SlaveAddr + R

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	while (RX_INT ==  0)							//Wait for RX
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	RX_INT = 0;										//Clear RX flag

	Data = RX_Data;									//Receive Byte

	I2C0->CMD = I2C_CMD_NACK;						//Send NACK CMD
	I2C0->CMD = I2C_CMD_STOP;						//Send Stop CMD

	return Data;
}




void MAX30105_I2C_WriteReg(uint8_t Register, uint8_t Value)
{
	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 0;		//SlaveAddr + W

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->TXDATA = Register;						//Send Register Byte

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->TXDATA = Value;							//Send value

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->CMD = I2C_CMD_STOP;						//Send Stop CMD
}




void MAX30105_GetFIFOData(Circular_Buff_t* C_Buff)
{
	/* Get the WRITE pointer */
	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 0;		//SlaveAddr + W

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->TXDATA = MAX30105_FIFOWRITEPTR;			//Send Register Byte

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 1;		//SlaveAddr + R

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	while (RX_INT ==  0)							//Wait for RX
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	RX_INT = 0;										//Clear RX flag

	uint8_t WritePointer = RX_Data;					//Receive Byte

	I2C0->CMD = I2C_CMD_NACK;						//Send NACK CMD
	I2C0->CMD = I2C_CMD_STOP;						//Send Stop CMD


	/* Get the READ pointer */
	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 0;		//SlaveAddr + W

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->TXDATA = MAX30105_FIFOREADPTR;			//Send Register Byte

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	I2C0->CMD = I2C_CMD_START;						//Send Start CMD

	I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 1;		//SlaveAddr + R

	while (ACK_INT ==  0)							//Wait for ACK
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	ACK_INT = 0;									//Clear ACK flag

	while (RX_INT ==  0)							//Wait for RX
	{
		SLEEP_Sleep();								//Sleep while waiting
	}
	RX_INT = 0;										//Clear RX flag

	uint8_t ReadPointer = RX_Data;					//Receive Byte

	I2C0->CMD = I2C_CMD_NACK;						//Send NACK CMD
	I2C0->CMD = I2C_CMD_STOP;						//Send Stop CMD


	int8_t NumofSamples = 0;

	/* Check if we have new data */
	if (ReadPointer != WritePointer)
	{
		/* Calculate the number of readings we need to get from sensor */
		NumofSamples = WritePointer - ReadPointer;

		if(NumofSamples < 0)
		{
			NumofSamples += 32;		//Wrap condition
		}

		I2C0->CMD = I2C_CMD_START;						//Send Start CMD

		I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 0;		//SlaveAddr + W

		while (ACK_INT ==  0)							//Wait for ACK
		{
			SLEEP_Sleep();								//Sleep while waiting
		}
		ACK_INT = 0;									//Clear ACK flag

		I2C0->TXDATA = MAX30105_FIFODATA;				//Send Register Byte

		while (ACK_INT ==  0)							//Wait for ACK
		{
			SLEEP_Sleep();								//Sleep while waiting
		}
		ACK_INT = 0;									//Clear ACK flag

		I2C0->CMD = I2C_CMD_START;						//Send Start CMD

		I2C0->TXDATA = (MAX30105_ADDRESS << 1) | 1;		//SlaveAddr + R

		while (ACK_INT ==  0)							//Wait for ACK
		{
			SLEEP_Sleep();								//Sleep while waiting
		}
		ACK_INT = 0;									//Clear ACK flag

		/* Get samples from sensor FIFO */
		uint8_t Byte_Data[sizeof(uint32_t)]; 				//Array of 4 bytes that we will convert into long
		uint32_t RED_LED_MEASUREMENT;

		/* Burst read three bytes each time - RED */
		for(uint32_t i = 0; i < NumofSamples; i++)
		{
			Byte_Data[3] = 0;								//This is always zero

			//Get Byte #3
			while (RX_INT ==  0)							//Wait for RX
			{
				SLEEP_Sleep();								//Sleep while waiting
			}
			RX_INT = 0;										//Clear RX flag

			Byte_Data[2] = RX_Data;							//Receive Byte

			I2C0->CMD = I2C_CMD_ACK;						//Send ACK

			//Get Byte #2
			while (RX_INT ==  0)							//Wait for RX
			{
				SLEEP_Sleep();								//Sleep while waiting
			}
			RX_INT = 0;										//Clear RX flag

			Byte_Data[1] = RX_Data;							//Receive Byte

			I2C0->CMD = I2C_CMD_ACK;						//Send ACK

			//Get Byte #1
			while (RX_INT ==  0)							//Wait for RX
			{
				SLEEP_Sleep();								//Sleep while waiting
			}
			RX_INT = 0;										//Clear RX flag

			Byte_Data[0] = RX_Data;							//Receive Byte

			//Convert array to long
			memcpy(&RED_LED_MEASUREMENT, Byte_Data, sizeof(RED_LED_MEASUREMENT));

			RED_LED_MEASUREMENT &= 0x3FFFF; 				//Zero out all but 18 bits

			/* Adding RED LED measurement to circular buffer */
			CircBuff_Add(C_Buff, RED_LED_MEASUREMENT);

			/* Check if we have more samples, then send ACK */
			if( (i + 1) != NumofSamples)
			{
				I2C0->CMD = I2C_CMD_ACK;					//Send ACK
			}
		}

		I2C0->CMD = I2C_CMD_NACK;							//Send NACK CMD
		I2C0->CMD = I2C_CMD_STOP;							//Send Stop CMD
	}
}




uint8_t MAX30105_GetPartID()
{
	uint8_t PartID = MAX30105_I2C_ReadReg(MAX30105_REG_PARTID);
	return PartID;
}



void I2C0_IRQHandler(void)
{
	//ACK Handler
	if(I2C0->IF & I2C_IF_ACK)
	{
		ACK_INT = 1;					//Set ACK flag
		I2C0->IFC = I2C_IFC_ACK;		//Clear ACK IF
	}

	//RX Handler
	if(I2C0->IF & I2C_IF_RXDATAV)
	{
		RX_INT = 1;						//Set RX flag
		RX_Data = I2C0->RXDATA;			//Receive Byte (This will also clear RXDATAV IF)
	}
}
