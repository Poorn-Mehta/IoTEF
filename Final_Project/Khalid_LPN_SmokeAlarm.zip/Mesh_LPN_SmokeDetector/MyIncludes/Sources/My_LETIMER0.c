/*
 * MyLETIMER0.c
 *
 *  Created on: Sep 17, 2018
 *      Author: ik5m
 */


#include "MyIncludes/Headers/My_LETIMER0.h"

#include <stdio.h>

#include "em_letimer.h"
#include "em_cmu.h"
#include "em_gpio.h"
#include "native_gecko.h"



void LETIMER0_Setup(double Period, uint8_t EnergyMode)
{

	CMU_ClockEnable(cmuClock_CORELE, true);
	CMU_ClockEnable(cmuClock_LETIMER0, true);

	/* Set configurations for LETIMER 0 */
	const LETIMER_Init_TypeDef LETimer0Init =
	{
		.enable         = false,            	//Don't start counting when initialization completes
		.debugRun       = false,                //Counter will not keep running during debug halt
		.comp0Top       = true,                 //Load COMP0 register into CNT when counter underflows
		.bufTop         = false,                //Don't load COMP1 into COMP0 when REP0 reaches 0
		.out0Pol        = 0,                    //Idle value for output 0
		.out1Pol        = 0,                    //Idle value for output 1
		.ufoa0          = letimerUFOANone,      //No output action
		.ufoa1          = letimerUFOANone,      //No output action
		.repMode        = letimerRepeatFree  	//Count until stopped
	};

	/* Initialize LETIMER */
	LETIMER_Init(LETIMER0, &LETimer0Init);

	uint16_t COMP0_VAL;			//This will store our COMP0 value after calculations
	uint16_t Freq; 				//This will store our frequency which depends on the Energy Mode selected
	uint32_t TotalCount;		//This will store the total count
	uint16_t Prescaler = 1; 	//These two variables keeps track of what Prescaler to use
	uint8_t PrescalerCount = 0;

	/* This IF statement handles how we will configure the rest of this LETIMER set-up, based on the Energy Mode.
	 * EM0-EM2 use LF and EM3 uses ULF */
	if (EnergyMode == 3)	//If EM3
	{
		CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_ULFRCO);		//Change the clock source
		Freq = 1000;	//ULF - 1000 Hz

		//This While Loop calculates how many times we need to divide
		TotalCount = Period * Freq;
		while(TotalCount > 65535)
		{
			Prescaler = 2 * Prescaler;
			TotalCount = TotalCount/Prescaler;
			PrescalerCount++;
		}
		CMU->LFAPRESC0 = PrescalerCount;	//This line will determine our Prescaler based on the previous while loop
		Freq = Freq/Prescaler;				//Gets the new Freq
	}
	else		//If EM0-EM2
	{
		CMU_ClockSelectSet(cmuClock_LFA, cmuSelect_LFXO);	//Change the clock source
		//LF - 32768 Hz
		Freq = 32768;

		//This While Loop calculates how many times we need to divide
		TotalCount = Period * Freq;
		while(TotalCount > 65535)
		{
			Prescaler = 2 * Prescaler;
			TotalCount = TotalCount/Prescaler;
			PrescalerCount++;
		}
		CMU->LFAPRESC0 = PrescalerCount;					//This line will determine our Prescaler based on the previous while loop
		Freq = Freq/Prescaler;								//Gets the new Freq
	}

	/* COMP0 */
	COMP0_VAL = Period*Freq;								//Calculates the COMP0 value needed for the desired Period
	LETIMER_CompareSet(LETIMER0, 0, COMP0_VAL);				//Sets the value to COMP0

	LETIMER0->IFC = LETIMER_IFC_UF;							//Clears UnderFlow Flag
	LETIMER_IntEnable(LETIMER0, LETIMER_IF_UF);				//Enables UnderFlow Flag
	NVIC_EnableIRQ(LETIMER0_IRQn);							//Enables LETIMER0 IRQ Handler
//	LETIMER_Enable(LETIMER0, true);							//Enables the LETIMER0
}




void LETIMER0_I2C_Atlas_Enable()
{
	LETIMER_Enable(LETIMER0, true);			//Enables the LETIMER0
}



void LETIMER0_I2C_Atlas_Disable()
{
	LETIMER_Enable(LETIMER0, false);		//Disables the LETIMER0
//	LETIMER_Reset(LETIMER0);				//Reset the LETIMER0
//	LETIMER0_Setup(1.0, 3);					//Re-init and set period to 1 sec
}



void LETIMER0_IRQHandler()
{
	uint32_t Flags;							//This will store any interrupt flags
	Flags = LETIMER_IntGet(LETIMER0); 		//Get any pending interrupts
	LETIMER_IntClear(LETIMER0, Flags);		//Clear interrupts

	//UnderFlow Handler
	if(Flags & LETIMER_IF_UF)
	{
		printf("\n\n");
		printf("> *********************************************************************\n");
		printf("> !!ERROR: I2C Atlas (WatchDog) detected an error in I2C communication!\n");
		printf("> Please check the sensor's wiring, the board will now be reset...\n");
		printf("> *********************************************************************\n");
		gecko_cmd_system_reset(0);

		Flags = 0;
	}
}
