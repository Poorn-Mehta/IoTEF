/*
 * MyButtons.c
 *
 *  Created on: Nov 6, 2018
 *      Author: ik5m
 */

#include "MyIncludes/Headers/My_Buttons.h"
#include <stdio.h>
#include "em_gpio.h"
#include "native_gecko.h"


void PB0_Setup()
{
	/* Set as INPUT with pull-up enabled */
	GPIO_PinModeSet(gpioPortF, 6, gpioModeInputPull, 1);

	/* Set Interrupt on Falling Edge and enable */
	GPIO_IntConfig(gpioPortF, 6, false, true, true);

	/* Enable TIMER0 interrupt vector in NVIC */
	NVIC_EnableIRQ(GPIO_EVEN_IRQn);

	printf("> PB0 initialized \n");
}




void PB1_Setup()
{
	/* Set as INPUT with pull-up enabled */
	GPIO_PinModeSet(gpioPortF, 7, gpioModeInputPull, 1);

	/* Set Interrupt on Falling Edge and enable */
	GPIO_IntConfig(gpioPortF, 7, false, true, true);

	/* Enable TIMER0 interrupt vector in NVIC */
	NVIC_EnableIRQ(GPIO_ODD_IRQn);

	printf("> PB1 initialized \n");
}




/* PB0 Handler */
void GPIO_EVEN_IRQHandler()
{
	uint32_t Flags;				//This will store any interrupt flags
	Flags = GPIO_IntGet(); 		//Get any pending interrupts
	GPIO_IntClear(Flags);		//Clear interrupts

	gecko_external_signal(Flags);
}



/* PB1 Handler */
void GPIO_ODD_IRQHandler()
{
	uint32_t Flags;				//This will store any interrupt flags
	Flags = GPIO_IntGet(); 		//Get any pending interrupts
	GPIO_IntClear(Flags);		//Clear interrupts

	gecko_external_signal(Flags);
}

