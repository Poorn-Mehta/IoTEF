/*
 * MyNode.c
 *
 *  Created on: Nov 6, 2018
 *      Author: ik5m
 */

#include <stdlib.h>
#include <stdio.h>
#include "native_gecko.h"
#include "mesh_generic_model_capi_types.h"
#include "mesh_lighting_model_capi_types.h"
#include "mesh_lib.h"
#include <mesh_sizes.h>
#include <MyIncludes/Headers/My_Node.h>
#include "gatt_db.h"
#include "MyIncludes/MyDefinesGlobals.h"
#include "lcd_driver.h"
#include "MyIncludes/Headers/My_CircBuff.h"
#include "MyIncludes/Headers/My_Flash.h"


extern uint16 Elem_Index; 					//For indexing elements of the node
extern Circular_Buff_t Sensor_Circ_Buff;
extern int16_t Current_Smoke_Level;
extern int16_t Last_Smoke_Level;


void SmokeAlarm_LPN_init()
{
	uint16 Result;

	Result = mesh_lib_init(malloc, free, 8);

	if(Result != 0)
	{
		printf("> !!ERROR: SmokeAlarm_LPN_init() - Mesh lib init failed!\n");
		printf("> !!Return code: 0x%x \n", Result);
		return;
	}

	/* Initialize LPN functionality */
	Result = gecko_cmd_mesh_lpn_init()->result;
	if(Result != 0)
	{
		printf("> !!ERROR: SmokeAlarm_LPN_init() - LPN init failed!\n");
		printf("> !!Return code: 0x%x \n", Result);
		return;
	}

	/* Configure LPN queue length and timeout */
	Result = gecko_cmd_mesh_lpn_configure(MIN_QUEUE_LENGTH, FRIEND_POLL_TIMEOUT_mS)->result;
	if (Result != 0)
	{
		printf("> !!ERROR: SmokeAlarm_LPN_init() - LPN config failed!\n");
		printf("> !!Return code: 0x%x \n", Result);
		return;
	}

	/* Finding friend */
	printf("> Trying to find friend...\n");
	Result = gecko_cmd_mesh_lpn_establish_friendship(0)->result;
	if (Result != 0)
	{
		printf("> !!ERROR: SmokeAlarm_LPN_init() - LPN establish friendship failed!\n");
		printf("> !!Return code: 0x%x \n", Result);

		/* Try to find friend again after short delay */
		Result  = gecko_cmd_hardware_set_soft_timer(FIND_FRIEND_TIME_IN_S, FIND_FRIEND_TIMER_ID, FIND_FRIEND_SINGLE_SHOT)->result;
		if (Result != 0)
		{
			printf("> !!ERROR: FIND_FRIEND_TIMER set failure!\n");
			printf("> !!Return code 0x%X\n", Result);
		}
	}
}



void Set_Node_name(bd_addr *Address)
{
  char Name[30];
  char BT_ADDR_String[40];

  uint16 Result;

  /* Create unique device name using the last two bytes of the Bluetooth address */
  sprintf(Name, "Smoke Alarm Node %X:%X", Address->addr[1], Address->addr[0]);

  snprintf(BT_ADDR_String, sizeof(BT_ADDR_String), "%0.2X:%0.2X:%0.2X:%0.2X:%0.2X:%0.2X",
		  Address->addr[5], Address->addr[4], Address->addr[3],
		  Address->addr[2], Address->addr[1], Address->addr[0]);

  LCD_write("Smoke Alarm Node", LCD_NODE_NAME);
  LCD_write(BT_ADDR_String, LCD_NODE_ADDR);

  printf("> Device name: '%s'\n", Name);

  Result = gecko_cmd_gatt_server_write_attribute_value(gattdb_device_name, 0, strlen(Name), (uint8 *)Name)->result;
  if(Result != 0)
  {
	printf("> !!ERROR: Set_Node_name() - gecko_cmd_gatt_server_write_attribute_value() failed!\n");
	printf("> !!Return code: 0x%x \n", Result);
  }
}



void SmokeLevelCheck(Circular_Buff_t* C_Buff)
{
	uint32_t GotSmokeLevel = 0;

	/* If function is successful, execute the rest of the statement, else skip */
	if( CircBuff_Peek(&Sensor_Circ_Buff, &GotSmokeLevel) == 0 )
	{
		/* Check current smoke level and set alarm level */
		if(GotSmokeLevel < 100)
		{
			LCD_write("", LCD_SMOKE_DETECTED);
			Current_Smoke_Level = 0;
		}
		else if( (100 <= GotSmokeLevel) && (GotSmokeLevel < 200) )
		{
			LCD_write("", LCD_SMOKE_DETECTED);
			Current_Smoke_Level = 1;
		}
		else if( (200 <= GotSmokeLevel) && (GotSmokeLevel < 300) )
		{
			LCD_write("", LCD_SMOKE_DETECTED);
			Current_Smoke_Level = 2;
		}
		else if( (300 <= GotSmokeLevel) && (GotSmokeLevel < 400) )
		{
			LCD_write("", LCD_SMOKE_DETECTED);
			Current_Smoke_Level = 3;
		}
		else if( (400 <= GotSmokeLevel) && (GotSmokeLevel < 500) )
		{
			LCD_write("", LCD_SMOKE_DETECTED);
			Current_Smoke_Level = 4;
		}
		else if( (500 <= GotSmokeLevel) && (GotSmokeLevel < 600) )
		{
			LCD_write("", LCD_SMOKE_DETECTED);
			Current_Smoke_Level = 5;
		}
		else if( 600 <= GotSmokeLevel )
		{
			Current_Smoke_Level = 6;

			/* Smoke was detected, publish an alarm to the group */
			LCD_write("SMOKE DETECTED!", LCD_SMOKE_DETECTED);
			Generic_Level_Update_Publish_Alarm();
		}

		/* Update alarm level in server model for client to get when requested */
		Generic_Level_Update_SmokeLevel(Current_Smoke_Level);

		/* To avoid updating the LCD and flash if the smoke level has not changed, I have a global variable
		 * that stores the last smoke level and compares it to the new smoke level. If they are the same
		 * the processor will not waste time updating the LCD or flash as it's nothing new.
		 *
		 * NOTE:
		 * You may be wondering why am I calling Generic_Level_Update_SmokeLevel() if the smoke level has not changed?
		 * Well, in our implementation of Bluetooth mesh we are limited to only using one model, And as a workaround,
		 * we are using just one model to handle all our communications (not good... but Silicon Labs provisoner sucks and
		 * doesn't allow us to have more than one model in a group...). So if I send out an alarm, I have to update my smoke
		 * level after or the client will get 0x7FFF (the alarm value) as opposed to the expected smoke level of 6. (Again,
		 * because I am using one model to share data)
		 */
		if(Current_Smoke_Level != Last_Smoke_Level)
		{
			/* Display updated smoke level on LCD */
			char SmokeLevel_String[15];
			snprintf(SmokeLevel_String, sizeof(SmokeLevel_String), "Smoke Level: %d", Current_Smoke_Level);
			LCD_write(SmokeLevel_String, LCD_SMOKE_LEVEL);

			/* Store updated smoke level in flash storage */
			Flash_Store_Byte(Current_Smoke_Level, FLASH_PS_KEY_SMOKELEVEL);

			Last_Smoke_Level = Current_Smoke_Level;
		}
		else
		{
			printf("> Smoke level unchanged: LCD and flash were not updated\n");
		}
	}
}



void Generic_Level_Update_Publish_Alarm()
{
	struct mesh_generic_state Custom_Data;
	errorcode_t Result;
	Custom_Data.kind = mesh_generic_state_level;
	Custom_Data.level.level = 0x7FFF;				//We chose the value of 0x7FFF to represent an alarm (workaround to only
													//having one model in mesh network (due to provisioner issues))

	Result = mesh_lib_generic_server_update(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
											  Elem_Index,
											  &Custom_Data,
											  0,
											  0);

	/* Error checking and reporting */
	if(Result != 0)
	{
		printf("> !!ERROR: Generic_Level_Update_Publish_Alarm() - mesh_lib_generic_server_update() failed!\n");
		printf("> !!Return code: 0x%x \n", Result);
	}
	else
	{
		Result = mesh_lib_generic_server_publish(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
												 Elem_Index,
												 mesh_generic_state_level);


		/* Error checking and reporting */
		if(Result != 0)
		{
			printf("> !!ERROR: Generic_Level_Update_Publish_Alarm() - mesh_lib_generic_server_publish() failed!\n");
			printf("> !!Return code: 0x%x \n", Result);
			return;
		}

		/* Confirmation */
		printf("> Generic_Level_Update_Publish_Alarm(): Alarm sent to group!\n");
	}
}



void Generic_Level_Update_SmokeLevel(int16_t Smoke_Level)
{
	struct mesh_generic_state Custom_Data;
	errorcode_t Result;

	Custom_Data.kind = mesh_generic_state_level;
	Custom_Data.level.level = Smoke_Level;


	Result = mesh_lib_generic_server_update(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
											  Elem_Index,
											  &Custom_Data,
											  0,
											  0);

	if(Result != 0)
	{
		printf("> !!ERROR: Generic_Level_Update_SmokeLevel() - mesh_lib_generic_server_update() failed!\n");
		printf("> !!Return code: 0x%x \n", Result);
		return;
	}

	printf("> Generic_Level_Update_SmokeLevel(): Smoke level updated! Value: %d\n", Smoke_Level);
}

