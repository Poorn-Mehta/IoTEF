/*
 * MyFlash.c
 *
 *  Created on: Nov 6, 2018
 *      Author: ik5m
 */
#include "MyIncludes/Headers/My_Flash.h"
#include <stdio.h>
#include "native_gecko.h"
#include "MyIncludes/MyDefinesGlobals.h"
#include "lcd_driver.h"

extern uint8 Connection_Handle;      		//Handle of the last opened BLE connection


void Flash_Reset(void)
{
	LCD_Clear();

	LCD_write("******************", 5);
	LCD_write("* CLEARING FLASH *", 6);
	LCD_write("******************", 7);

	printf("> Clearing flash...\n");

	/* If connection is open then close it before rebooting */
	if(Connection_Handle != 0xFF)
	{
		gecko_cmd_le_connection_close(Connection_Handle);
	}

	gecko_cmd_flash_ps_erase_all();

	printf("> Success!\n");

	/* Reboot node after a delay */
	gecko_cmd_hardware_set_soft_timer(FLASH_RESET_TIME_IN_S, FLASH_RESET_TIMER_ID, FLASH_RESET_SINGLE_SHOT);
}




void Flash_Store_Byte(uint8_t DataToStore, uint16_t PS_Key)
{
	/* Error check: is PS key within range? */
	if( (0x4000 <= PS_Key) && (PS_Key <= 0x407F) )
	{
		/* Saving to flash */
		uint16 Result = gecko_cmd_flash_ps_save(PS_Key, 1, &DataToStore)->result;
		if(Result != 0)
		{
			printf("> !!ERROR: Flash_Store_Byte() - gecko_cmd_flash_ps_save() error!\n");
			printf("> !!Return code: 0x%x \n", Result);
			return;
		}

		printf("> Flash_Store_Byte() success! Stored: %u at PS_Key address 0x%X\n", DataToStore, PS_Key);
	}
	else
	{
		printf("> !!ERROR: Flash_Store_Byte() - PS Key value must be between 0x4000 to 0x407F!\n");
	}
}



int8_t Flash_Load_Byte(uint8_t* LoadData, uint16_t PS_Key)
{
	/* Error check: is PS key within range? */
	if( (0x4000 <= PS_Key) && (PS_Key <= 0x407F) )
	{
		struct gecko_msg_flash_ps_load_rsp_t* Flash_Resp;

		/* Loading from flash */
		Flash_Resp = gecko_cmd_flash_ps_load(PS_Key);
		if(Flash_Resp->result != 0)
		{
			/* This error means no data was written to that flash location yet */
			if(Flash_Resp->result == 0x0502)
			{
				printf("> Flash_Load_Byte(): No flash data has been stored yet\n");
				return -2;
			}
			else
			{
				printf("> !!ERROR: Flash_Load_Byte() - gecko_cmd_flash_ps_load() error!\n");
				printf("> !!Return code: 0x%x \n", Flash_Resp->result);
				return -1;
			}
		}
		*LoadData = Flash_Resp->value.data[0];
		return 0;
	}
	else
	{
		printf("> !!ERROR: Flash_Load_Byte() - PS Key value must be between 0x4000 to 0x407F!\n");
		return -1;
	}
}
