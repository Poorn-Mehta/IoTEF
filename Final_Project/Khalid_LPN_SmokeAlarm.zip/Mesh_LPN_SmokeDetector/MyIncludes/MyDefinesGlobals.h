/*
 * MyDefinesGlobals.h
 *
 *  Created on: Nov 6, 2018
 *      Author: ik5m
 */

#ifndef MYINCLUDES_MYDEFINESGLOBALS_H_
#define MYINCLUDES_MYDEFINESGLOBALS_H_

#include <bg_types.h>

/***************************************
 *          Flash defines              *
 ***************************************/
#define FLASH_PS_KEY_SMOKELEVEL		0x4020


/***************************************
 *          LCD defines                *
 ***************************************/
#define LCD_MESH_TEXT 				2
#define LCD_SMOKE_DETECTED			3
#define LCD_NODE_NAME 				4
#define LCD_NODE_ADDR 				5
#define LCD_LPN_STATUS				6
#define LCD_SMOKE_LEVEL				7
#define LCD_PROV_STATUS 			8
#define LCD_PASSKEY_TEXT 			9
#define LCD_PASSKEY_NUM				10
#define LCD_FRIEND_STATUS			11
#define LCD_CONN_STATUS				12

/*---------------Text------------------*/
#define NO_FRIEND_TEXT "No friend u_u"
#define FRIEND_TEXT "Friend conntd. n_n"


/***************************************
 *        LETIMER0 defines             *
 ***************************************/
#define PERIOD_S					1
#define ENERGY_MODE					3


/***************************************
 *          Mesh defines               *
 ***************************************/
#define PB_ADV						0x01			//PB-Adv Bearer
#define PB_GATT						0x02			//PB-GATT Bearer
#define PUBLIC_KEY 					0x00

/*---------------Auth_methods------------------*/
#define NO_OOB						0x01
#define STATIC_OOB					0x02
#define INPUT_OOB					0x03
#define OUTPUT_OOB					0x08

/*---------------Output_actions------------------*/
#define OUTPUT_NUMERIC				0x03
#define OUTPUT_SIZE					0x02			//Range: 0x01�0x08

/*---------------Input_actions------------------*/
#define DONT_CARE					0x00

/*---------------LPN------------------*/
#define MIN_QUEUE_LENGTH			2
#define FRIEND_POLL_TIMEOUT_mS		(10 * 1000)



/***************************************
 *        Button defines               *
 ***************************************/
#define PB0_Flag 					0x40		//BIT 6
#define PB1_Flag 					0x80		//BIT 7



/***************************************
 *     MAX30105 Sensor defines         *
 ***************************************/
/*---------------Sensor Setup------------------*/
//Check the MAX30105_Sensor_Setup() function in the My_MAX30105.h file to understand the numbers
#define SAMPLE_AVG					6			//Avg 32 samples
#define ADC_RANGE					4			//16384
#define SAMPLE_RATE					7			//1600 samples per second
#define PULSE_WIDTH					3			//215 uS
#define POWER_LEVEL					0x14



/***************************************
 *        Timer defines                *
 ***************************************/
/*---------------Flash Timer------------------*/
#define FLASH_RESET_TIMER_ID			1			//Flash reset timer unique ID
#define FLASH_RESET_TIME_IN_S		(2 * 32768)		//The value is multiplied by 32768 as the gecko_cmd_hardware_set_soft_timer expects
#define FLASH_RESET_SINGLE_SHOT			1			//0 => false (timer is repeating) or 1 => true (timer runs only once)

/*---------------Friend Timer------------------*/
#define FIND_FRIEND_TIMER_ID			2			//Find friend timer unique ID
#define FIND_FRIEND_TIME_IN_S		(2 * 32768)		//The value is multiplied by 32768 as the gecko_cmd_hardware_set_soft_timer expects
#define FIND_FRIEND_SINGLE_SHOT			0			//0 => false (timer is repeating) or 1 => true (timer runs only once)

/*---------------Sensor Timer------------------*/
#define GET_SENSOR_DATA_TIMER_ID		3			//Get sensor data unique ID
#define GET_SENSOR_DATA_TIME_IN_S	(3 * 32768)		//The value is multiplied by 32768 as the gecko_cmd_hardware_set_soft_timer expects
#define GET_SENSOR_DATA_SINGLE_SHOT		0			//0 => false (timer is repeating) or 1 => true (timer runs only once)

/*---------------Re-init LPN Timer------------------*/
#define REINIT_LPN_TIMER_ID				4			//Re-init LPN unique ID
#define REINIT_LPN_TIME_IN_S		(60 * 32768)	//The value is multiplied by 32768 as the gecko_cmd_hardware_set_soft_timer expects
#define REINIT_LPN_SINGLE_SHOT			1			//0 => false (timer is repeating) or 1 => true (timer runs only once)

#endif /* MYINCLUDES_MYDEFINESGLOBALS_H_ */
