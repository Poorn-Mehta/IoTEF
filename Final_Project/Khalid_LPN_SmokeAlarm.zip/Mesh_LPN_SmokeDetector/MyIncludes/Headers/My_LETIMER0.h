/*
 * MyLETIMER0.h
 *
 *  Created on: Sep 17, 2018
 *      Author: ik5m
 */

#ifndef MYHEADERS_MYLETIMER0_H_
#define MYHEADERS_MYLETIMER0_H_

#include <stdint.h>


/**************************************************************************************************************
 * USAGE: This function sets up the LETIMER0
 *        - Enables needed clocks that were not already enabled
 *        - Configures and initializes LETIMER0
 *        - Computes the needed Prescaler automatically
 *        - Computes needed COMP0 value (used as TOP value) based on Period and Energy Mode
 *        - Enables UnderFlow Interrupt and LETIMER0_IRQn
 *
 * PARAMETERS:
 *            - double Period => Input desired Period in Seconds
 *            - uint8_t EnergyMode => Enter the EnergyMode you will run you device at (EM0-EM3 = 0-3)
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void LETIMER0_Setup(double Period, uint8_t EnergyMode);


/**************************************************************************************************************
 * USAGE: This function enables the LETIMER0 using it as an I2C watchdog. If the LETIMER0 is not disabled
 *        in one second (using LETIMER0_I2C_Atlas_Disable()), the board will be reset.
 *        It was named Atlas instead of WatchDog because of my dog is named Atlas :)
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void LETIMER0_I2C_Atlas_Enable();


/**************************************************************************************************************
 * USAGE: This function disables and resets the LETIMER0.
 *        It was named Atlas instead of WatchDog because of my dog is named Atlas :)
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void LETIMER0_I2C_Atlas_Disable();


/**************************************************************************************************************
 * USAGE: This is the LETIMER0 IRQ Handler that will reset the board in case of an I2C communication error.
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void LETIMER0_IRQHandler();


#endif /* MYHEADERS_MYLETIMER0_H_ */
