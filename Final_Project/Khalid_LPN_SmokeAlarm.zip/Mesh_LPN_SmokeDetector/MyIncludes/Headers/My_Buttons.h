/*
 * MyButtons.h
 *
 *  Created on: Nov 6, 2018
 *      Author: ik5m
 */

#ifndef MYINCLUDES_HEADERS_MY_BUTTONS_H_
#define MYINCLUDES_HEADERS_MY_BUTTONS_H_

/**************************************************************************************************************
 * USAGE: This function sets up PB0 as an INPUT with pull-up enabled
 *
 * PARAMETERS:
 *            - None
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void PB0_Setup();

/**************************************************************************************************************
 * USAGE: This function sets up PB1 as an INPUT with pull-up enabled
 *
 * PARAMETERS:
 *            - None
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void PB1_Setup();


/**************************************************************************************************************
 * USAGE: This is the GPIO EVEN IRQ Handler
 *
 * PARAMETERS:
 *            - None
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void GPIO_EVEN_IRQHandler();


/**************************************************************************************************************
 * USAGE: This is the GPIO EVEN IRQ Handler
 *
 * PARAMETERS:
 *            - None
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void GPIO_ODD_IRQHandler();


#endif /* MYINCLUDES_HEADERS_MY_BUTTONS_H_ */
