/*
 * My_MAX30105.h
 *
 *  Created on: Dec 2, 2018
 *      Author: ik5m
 */

#ifndef MY_MAX30105_H_
#define MY_MAX30105_H_

#include <stdint.h>
#include <stdbool.h>

#include "My_CircBuff.h"


/*
 * My_MAX30105.h
 *
 *  Created on: Dec 2, 2018
 *      Author: Khalid AlAwadhi
 *
 * NOTE: This library depends on My_CircBuff.h because it uses a circular buffer to store data
 *       coming in from the sensor
 *
 * This library was heavily influenced by the Arduino code written by
 * Peter Jansen and Nathan Seidle (SparkFun). It helped out a lot.
 */


/**************************************************************************************************************
 * USAGE: This function configures I2C communication with the MAX30105 sensor.
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void MAX30105_I2C_Setup();



/**************************************************************************************************************
 * USAGE: This function sets up the sensor based on user setting, currently, only the RED LED is supported,
 * 		  however, simple modifications can add the IR and Green LEDs.
 * 		  Look at page 24 in the datasheet for proper ways to set parameters.
 * 		  Options are shown below in parameters: (in case of unexpected input, the default value will be used)
 *
 * PARAMETERS:
 *            - uint8_t Sensor_Sample_Average: 1 = No sample averaging
 *            								   2 = Avg 2 samples
 *            								   3 = Avg 4 samples				[DEFAULT]
 *            								   4 = Avg 8 samples
 *            								   5 = Avg 16 samples
 *            								   6 = Avg 32 samples
 *
 *            - uint8_t ADC_Range: 			   1 = 2048							[DEFAULT]
 *            								   2 = 4096
 *            								   3 = 8192
 *            								   4 = 16384
 *
 *            - uint8_t Sample_Rate: 		   1 = 50 samples per second		[DEFAULT]
 *            								   2 = 100 samples per second
 *            								   3 = 200 samples per second
 *            								   4 = 400 samples per second
 *            								   5 = 800 samples per second
 *            								   6 = 1000 samples per second
 *            								   7 = 1600 samples per second
 *            								   8 = 3200 samples per second
 *
 *            	//Longer pulse width corresponds to a longer range of detection
 *            - uint8_t Pulse_Width:		   1 = 69 uS 	   15 bit res // ~2 inches			[DEFAULT]
 *                                             2 = 118 uS      16 bit res
 *                                             3 = 215 uS	   17 bit res
 *                                             4 = 411 uS      18 bit res // ~6 inches
 *
 *              //Power level range is from 0x00 to 0xFF, below are some options:
 *            - uint8_t Power_Level: 		  0x02 = Detection of ~4 inches  // 0.4 mA
 *                                            0x1F = Detection of ~8 inches  // 6.4 mA
 *                                            0x7F = Detection of ~8 inches  // 25.4 mA
 *                                            0xFF = Detection of ~12 inches // 50.0 mA
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void MAX30105_Sensor_Setup(uint8_t Sensor_Sample_Average, uint8_t ADC_Range, uint8_t Sample_Rate,
		                   uint8_t Pulse_Width, uint8_t Power_Level);



/**************************************************************************************************************
 * USAGE: This function masks the option chosen and sets in selected register of the MAX30105 sensor.
 *
 * PARAMETERS:
 *            - uint8_t Register: register to modify
 *            - uint8_t Mask: the mask of the register
 *            - uint8_t Option: the option to set
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void MAX30105_BITMask_Set(uint8_t Register, uint8_t Mask, uint8_t Option);



/**************************************************************************************************************
 * USAGE: This function reads from a register in the MAX30105 sensor
 *
 * PARAMETERS:
 *            - uint8_t Register: register to read from
 *
 * RETURNS: uint8_t Data_from_register
 *
 **************************************************************************************************************/
uint8_t MAX30105_I2C_ReadReg(uint8_t Register);



/**************************************************************************************************************
 * USAGE: This function writes to a register in the MAX30105 sensor
 *
 * PARAMETERS:
 *            - uint8_t Register: register to write to
 *            - uint8_t Value: value to write
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void MAX30105_I2C_WriteReg(uint8_t Register, uint8_t Value);



/**************************************************************************************************************
 * USAGE: This function will get the FIFO contents of the MAX30105 sensor. Sensor may need some time to gather
 *        new data depending on your setting (few mS not more). It will store the data from the sensor into
 *        the provided circular buffer.
 *
 * PARAMETERS:
 *            - Circular_Buff_t* C_Buff: Pass on the circular buffer to store data to
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void MAX30105_GetFIFOData(Circular_Buff_t* C_Buff);



/**************************************************************************************************************
 * USAGE: This function gets the MAX30105 sensor part ID.
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: uint8_t Part_ID: part ID of the MAX30105 sensor (should be 0x15)
 *
 **************************************************************************************************************/
uint8_t MAX30105_GetPartID();



/**************************************************************************************************************
 * USAGE: I2C0 IRQ Handler
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void I2C0_IRQHandler();




#endif /* MY_MAX30105_H_ */
