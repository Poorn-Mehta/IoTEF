/*
 * MyFlash.h
 *
 *  Created on: Nov 6, 2018
 *      Author: ik5m
 */

#ifndef MYINCLUDES_HEADERS_MY_FLASH_H_
#define MYINCLUDES_HEADERS_MY_FLASH_H_

#include <stdint.h>


/**************************************************************************************************************
 * USAGE: This function clears all flash memory, basically factory resetting the board. This removes all the
 * PS keys and other settings that have been configured for the node.
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void Flash_Reset();



/**************************************************************************************************************
 * USAGE: This function can be used to store a byte into flash persistent storage (PS) using a key value. The
 *        value of the PS Key must be between 0x4000 to 0x407F as that is what the datasheet says.
 *
 * PARAMETERS:
 *            - uint8_t DataToStore: the data byte you want to store
 *            - uint16_t PS_Key: the PS key value to store data into (0x4000 to 0x407F)
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void Flash_Store_Byte(uint8_t DataToStore, uint16_t PS_Key);


/**************************************************************************************************************
 * USAGE: This function loads a byte from flash persistent storage (PS) using a key value. The
 *        value of the PS Key must be between 0x4000 to 0x407F as that is what the datasheet says.
 *
 * PARAMETERS:
 *            - uint8_t* LoadData: variable to store the loaded data
 *            - uint16_t PS_Key: the PS key value to load data from (0x4000 to 0x407F)
 *
 * RETURNS: - Success: 0
 *          - Flash load error: -1
 *          - No flash data has been stored at given PS key value: -2
 *
 **************************************************************************************************************/
int8_t Flash_Load_Byte(uint8_t* LoadData, uint16_t PS_Key);



#endif /* MYINCLUDES_HEADERS_MY_FLASH_H_ */
