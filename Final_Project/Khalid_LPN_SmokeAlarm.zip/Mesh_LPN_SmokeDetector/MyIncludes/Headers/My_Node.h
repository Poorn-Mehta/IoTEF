/*
 * MyNode.h
 *
 *  Created on: Nov 6, 2018
 *      Author: Khalid AlAwadhi
 */

#ifndef MYINCLUDES_HEADERS_MY_NODE_H_
#define MYINCLUDES_HEADERS_MY_NODE_H_


#include "MyIncludes/Headers/My_CircBuff.h"


/**************************************************************************************************************
 * USAGE: This function initializes the node to be a Low-Power node
 *
 * PARAMETERS:
 *            - None
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void SmokeAlarm_LPN_init();



/**************************************************************************************************************
 * USAGE: This function sets a unique name to the node based on the last two bytes of its Bluetooth address.
 *
 * PARAMETERS:
 *            - bd_addr *Address: Bluetooth address
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void Set_Node_name(bd_addr *Address);



/**************************************************************************************************************
 * USAGE: This function checks the current smoke level and stores it in the circular buffer. After which it
 *        will send an alarm to the group if needed and update the smoke level server model and store it in flash.
 *
 * PARAMETERS:
 *            - Circular_Buff_t* C_Buff: Pass the circular buffer that contains the smoke levels
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void SmokeLevelCheck(Circular_Buff_t* C_Buff);



/**************************************************************************************************************
 * USAGE: This function will send out an alarm to the mesh network if called.
 *
 * PARAMETERS:
 *            - NONE
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void Generic_Level_Update_Publish_Alarm();



/**************************************************************************************************************
 * USAGE: This function will update the smoke level model for when the client asks for it, it will be ready.
 *
 * PARAMETERS:
 *            - int16_t Smoke_Level: Smoke level to update node with.
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void Generic_Level_Update_SmokeLevel(int16_t Smoke_Level);



#endif /* MYINCLUDES_HEADERS_MY_NODE_H_ */
