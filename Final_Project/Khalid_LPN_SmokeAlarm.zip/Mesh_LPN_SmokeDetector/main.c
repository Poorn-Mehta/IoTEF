/*
 * IoT Final Project:
 * Bluetooth Mesh Low-Power Node (Smoke Alarm) which utilizes the MAX30105 sensor
 * connected to the I2C ports. This is a very brief description, please look at the code for
 * a lot of information, explanation, and in-depth description of this project and how it operates.
 *
 *      Author: Khalid AlAwadhi
 *      Fall 2018
 *
 *
 *
 * Thanks to Poorn for writing the following overall system description:
 *
 * Model Being Used: Generic Level Client
 *>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>NODE OVERVIEW<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
 * This node is part of a project which uses Bluetooth mesh network to share important information
 * obtained from variety of sensors, and to act upon it.
 *
 * This node was tested along with 3 other nodes - all using Generic Level Servers
 * Due to limitation of the provisioner made available by Silicon Labs, only one model is used
 * CAUTION - This node uses the standard model in non standard model to achieve full functionality
 * This node works as the central device of the star network being formed (using mesh stack)
 *
 * Following are the nodes and their functionality:
 *
 * Khalid
 * Node 1 - Smoke [CURRENT PROJECT] - Low Power <Generic Level Server> | Persistent Data: Smoke Level
 * 			Measures the smoke level of the entity that it is configured for, and raises the alarm when
 * 			it crosses the predetermined threshold. Even this LPN's threshold can be updated dynamically,
 * 			similarly to that of the Moisture node, however it wasn't included due to time restrictions.
 * 			Besides Alarm, this node updates the scaled down smoke level value which is read from Central
 * 			node on a button press.
 *
 * 			-> PUBLISHES 0x7FFF to the ALARM GROUP to notify the group about high smoke level
 * 			-> Updates server with scaled smoke level, which is then made available to central node through
 * 				mesh stack. This uses UNICAST messaging since the central node uses client_get()
 *
 * John
 * NODE 2 - Moisture - Low Power <Generic Level Server>
 * 			Measure moisture level using a specific sensor. Sets alarm threshold based on the Lux value
 * 			received from another node which uses Lux sensor, and communicates to this <moisture> node
 * 			via central node. When the moisture level crosses the threshold (which is dynamically
 * 			determined using the light level presented), it raises the alarm - which is based on central node.
 *
 * 			-> PUBLISHES 0x7FFF (highest value for int8_t - which is the value type of the model being used)
 * 				to the ALARM GROUP as a mean to convey the message that the moisture alarm is raised
 * 			-> Communicates to Central node through UNICAST messaging, when the central node uses a
 * 				client_set on this node. The central node basically just relays the Lux level (also referred
 * 				to as Threshold level in the present code) - without knowing how to use or interpret that.
 * 				That task is solely up to the Moisture node. Lux node and Moisture nodes should agree and
 * 				establish a method to effectively communicate with each other
 * 			-> PUBLISHES the actual moisture level when the Alarm is OFF.
 *
 * Andrew
 * Node 3 - Lux/Door - Friend <Generic Level Server>
 * 			Measures the intensity of light and converts it to Lux. Additionally, it (ideally) controls
 * 			a secured door using magnetic lock, which is driven by central node through fingerprint
 * 			sensor implemented on it. Moreoever, it has the capability to send an alarm - either indicating
 * 			that the door was forcefully opened somehow (by implementing special sensor) - or when the light
 * 			is 'too' bright. The functionality can be easily set and determined by the node. However, other
 * 			nodes in network need to know it in order to correctly interpret/use the information provided.
 *
 * 			-> PUBLISHES 0x7FFF to the ALARM GROUP to raise an alarm.
 * 			-> PUBLISHES the scaled Lux level (or threshold level) periodically when the alarm is OFF
 * 			-> Communicates to Central through UNICAST messaging - in both ways. Central node polls
 * 				this node at every fixed interval (5 seconds now) using client_get() to receive the
 * 				Lux/Threshold level values.
 * 			-> Central node sends this node 0x7FFF when it recognizes a fingerprint that was stored in the
 * 				database as the one belonging to a person authorized to open the secure door. This is done
 * 				by central node using client_set() on this Lux/Door node.
 *
 * Node 4 - Fingerprint/Central  - Friend - <Generic Level Client> | Persistent Data: Alarm Status
 * 			Subscribed to the Alarm Group. Sounds a buzzer whenever any Alarm ON is published to the group.
 * 			Displays the combination of nodes which has raise the Alarm before it was manually cleared by
 * 			presseing button 0 (PB0 - Push Button 0). Stores is to the flash - which is useful if the alarm
 * 			was on and the node went through a power cycle. On button 1 press, it gets smoke level from
 * 			Smoke node using UNICAST client get(). It also integrates fingerprint scanner to which, new
 * 			fingerprints can be added by a few means. When a stored/valid fingerprint is pressed, the node
 * 			sends the command of Door Open to Lux/Door node by using client_set() on that node, and with
 * 			the value of 0x7FFF. This node polls Lux/Door node for new scaled Lux/Threshold value. If it
 * 			is different from the last one, then relays it to Moisture node.
 *
 * 			-> SUBSCRIBES to the group. Services the Alarm.
 * 			-> If any node publishes any other value than the ALARM ON (0x7FFF) then treats is uniquely.
 * 				Moisture node's publishes are treated as Mositure Level absolute values, Lux/Door node's
 * 				publishes are treated as scaled Lux level. Smoke node's publishes are treated as scaled
 * 				Smoke Level.
 * 			-> Communicates to all 3 nodes using UNICAST messaging.
 * 				- To/From Smoke - Gets smoke level on PB1 press (client_get()).
 * 				- To/From Lux/Door - Gets lux level periodically (client_get()). Sets Door state to Open (client_set()).
 * 				- To/From Moisture - Sets threshold level (a.k.a. scaled Lux level) if it is different from last received
 * 										lux level.
 *
 *****************************************************************************************************/

/* C Standard Library headers */
#include <stdlib.h>
#include <stdio.h>

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "init_app.h"
#include "ble-configuration.h"
#include "board_features.h"
#include "retargetserial.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include <gecko_configuration.h>
#include <mesh_sizes.h>
#include "mesh_generic_model_capi_types.h"
#include "mesh_lib.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#include <em_gpio.h>
#include "em_core.h"
#include "platform/emdrv/sleep/inc/sleep.h"
#include "bsp_trace.h"

/* Device initialization header */
#include "hal-config.h"

#if defined(HAL_CONFIG)
#include "bsphalconfig.h"
#else
#include "bspconfig.h"
#endif


// bluetooth stack heap
#define MAX_CONNECTIONS 2

uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS) + BTMESH_HEAP_SIZE + 1760];

// Bluetooth advertisement set configuration
//
// At minimum the following is required:
// * One advertisement set for Bluetooth LE stack (handle number 0)
// * One advertisement set for Mesh data (handle number 1)
// * One advertisement set for Mesh unprovisioned beacons (handle number 2)
// * One advertisement set for Mesh unprovisioned URI (handle number 3)
// * N advertisement sets for Mesh GATT service advertisements
// (one for each network key, handle numbers 4 .. N+3)
//
#define MAX_ADVERTISERS (4 + MESH_CFG_MAX_NETKEYS)

// bluetooth stack configuration
extern const struct bg_gattdb_def bg_gattdb_data;

const gecko_configuration_t config =
{
  .bluetooth.max_connections = MAX_CONNECTIONS,
  .bluetooth.max_advertisers = MAX_ADVERTISERS,
  .bluetooth.heap = bluetooth_stack_heap,
  .bluetooth.heap_size = sizeof(bluetooth_stack_heap) - BTMESH_HEAP_SIZE,
  .bluetooth.sleep_clock_accuracy = 100,
  .gattdb = &bg_gattdb_data,
  .btmesh_heap_size = BTMESH_HEAP_SIZE,
#if (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
  .pa.config_enable = 1, // Enable high power PA
  .pa.input = GECKO_RADIO_PA_INPUT_VBAT, // Configure PA input to VBAT
#endif // (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
  .max_timers = 16,
  .sleep = SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
};

static void handle_gecko_event(uint32_t evt_id, struct gecko_cmd_packet *evt);
void mesh_native_bgapi_init(void);
bool mesh_bgapi_listener(struct gecko_cmd_packet *evt);


//########################################################################################
// TO-DO:
// 1- [COMPLETED] MAKE TO-DO LIST
// 2- [COMPLETED] IMPLEMENT LCD DRIVER
// 3- [COMPLETED] IMPLEMENT OUT OF BAND PROVISIONING
// 4- [COMPLETED] IMPLEMENT DEVICE NAME RENAME
// 5- [COMPLETED] FIX PROVISIONING
// 6- [COMPLETED] ADD FINDING AND CONNECTING WITH FRIEND
// 7- [COMPLETED] INITIATE LPN AFTER BECOMING FRIENDS
// 8- [COMPLETED] UPDATE SmokeAlarm_LPN_init() FUNCTION
// 9- [COMPLETED] FIX ISSUE OF FRIEND NOT CONNECTING AFTER PROVISIONING UNLESS RESET (PROBABLY LCD WRITE THING)
// 10- [COMPLETED] IMPLEMENT PB1
// 11- [COMPLETED] MODIFY PB0 AND PB! TO INCREMENT A NUMBER AND DISPLAY ON LCD
// 12- [COMPLETED] BROADCAST FAKE VALUES (PB0 ALARM, PB1 SMOKE LEVEL)
// 13- [NOT NEEDED ANYMORE! ACTUAL LINES ARE HERE] ADD PLACEHOLDER LINES FOR SENSOR
// 14- [COMPLETED] ADD SENSOR AND CIRCUATR BUFFER CODE FILES (NOICE!)
// 15- [COMPLETED] ADD SENSOR SETUP TO CODE FLOW
// 16- [COMPLETED] ADD CIRCULAR BUFFER INIT TO CODE FLOW
// 17- [COMPLETED] ADD SENSOR DATA MEASUREMENT AND STORING TO CODE FLOW
// 18- [COMPLETED | Clear ~100 | Smoke >~600] CALIBRATE SENSOR WITH TISSUE PAPER SMOKE
// 19- [COMPLETED] USE PRESISTANT MEMORY TO STORE LAST SMOKE LEVEL
// 20- [COMPLETED] REMOVE EXCESS CLASS INTIS
// 21- [COMPLETED!!!] CREATE AND IMPLEMENT I2C TIMOUT FUNCTIONALITY
// 22- [COMPLETED] ENABLE SENSOR TO STAY UP FOR 1 MIN IF PB0 IS PRESSED
// 23- [SCRAPPED - NOT ENOUGH TIME FOR TESTING] IMPLEMENT SENSOR POWER OFF AND WAKEUP FUNCTIONS
// 24- [SCRAPPED - LCD POWER CONSUMPTION IS LOW] TURN OFF LCD WHEN NODE IS ASLEEP
// 25- [COMPLETED] ALLOW MEASUREMENTS TO BE TAKEN AND STOREDS ALL THE TIME
// 26- [COMPLETED] LOOK OVER ENTIRE CODE AND UPDATE ANY COMMENTS AND FUNCTION DISCRIPTIONS
// 27- [SCRAPPED - NO TIME TO IMPLEMENT] ADD ABILITY TO DISABLE UART OUTPUT TO SAVE POWER
//
//########################################################################################

/***************************************
 *          My includes                *
 ***************************************/
#include "lcd_driver.h"
#include "MyIncludes/MyDefinesGlobals.h"
#include "MyIncludes/Headers/My_Buttons.h"
#include "MyIncludes/Headers/My_Flash.h"
#include "MyIncludes/Headers/My_Node.h"
#include "MyIncludes/Headers/My_CircBuff.h"
#include "MyIncludes/Headers/My_MAX30105.h"
#include "MyIncludes/Headers/My_LETIMER0.h"


/***************************************
 *        My Global Variables          *
 ***************************************/
//Mesh
uint8 Connection_Handle = 0xFF;      		//Handle of the last opened BLE connection
uint16 Elem_Index = 0; 						//For indexing elements of the node
uint16 My_Address = 0;    					//Address of the Primary Element of the Node
uint8 Num_Connections = 0;					//Number of active Bluetooth connections

//Circular Buffer
Circular_Buff_t Sensor_Circ_Buff;			//Circular buffer structure used to get data from the sensor
uint32_t BUFF_SIZE = 2;						//Buffer size

//Mesh Alarm
int16_t Current_Smoke_Level = 0;			//Used to store the current smoke level
int16_t Last_Smoke_Level = 0;				//Compared against Current_Smoke_Level to decide whether to update LCD and flash or not


int main()
{
	/* Initialize device, board and application */
	initMcu();
	initBoard();
	initApp();

	BSP_TraceProfilerSetup();

	/* Mesh initialization stuff */
	gecko_stack_init(&config);
	gecko_bgapi_class_system_init();
	gecko_bgapi_class_le_gap_init();
	gecko_bgapi_class_le_connection_init();
	gecko_bgapi_class_gatt_init();
	gecko_bgapi_class_gatt_server_init();
	gecko_bgapi_class_endpoint_init();
	gecko_bgapi_class_hardware_init();
	gecko_bgapi_class_flash_init();
	gecko_bgapi_class_sm_init();
	mesh_native_bgapi_init();

	/* Added */
	gecko_bgapi_class_mesh_node_init();
	gecko_bgapi_class_mesh_proxy_init();
	gecko_bgapi_class_mesh_proxy_server_init();
	gecko_bgapi_class_mesh_generic_server_init();
	gecko_bgapi_class_mesh_health_client_init();
	gecko_bgapi_class_mesh_health_server_init();
	gecko_bgapi_class_mesh_lpn_init();

	gecko_initCoexHAL();

	/* Initializes the UART */
	RETARGET_SerialInit();
	RETARGET_SerialCrLf(true);

	printf("\n\n\n ***************Booting up...**************\n");

	/* Initialize the LCD */
	LCD_init();

	/* Initialize PB0 */
	PB0_Setup();

	/* Initialize PB1 */
	PB1_Setup();

	/* Initialize LETIMER0 */
	printf("> Initializing LETIMER0...\n");
	LETIMER0_Setup(PERIOD_S, ENERGY_MODE);


	/* Initialize circular buffer structure */
	printf("> Initializing Circular Buffer...\n");
	if( CircBuff_Init(&Sensor_Circ_Buff, BUFF_SIZE) )
	{
		printf("> ERROR: Circular Buffer init failed!\n");
	}

	/* Atlas enable and disable are used to keep track of I2C communication errors */
	LETIMER0_I2C_Atlas_Enable();			//Enable Atlas

	/* Initialize I2C communication with sensor */
	printf("> Initializing I2C communication with MAX30105 sensor...\n");
	SLEEP_SleepBlockBegin(sleepEM2);		//Block EM2
	MAX30105_I2C_Setup();

	/* Setup sensor */
	printf("> Configuring MAX30105 sensor with chosen settings...\n");
	MAX30105_Sensor_Setup(SAMPLE_AVG, ADC_RANGE, SAMPLE_RATE, PULSE_WIDTH, POWER_LEVEL);
	SLEEP_SleepBlockEnd(sleepEM2);			//Unblock EM2
	LETIMER0_I2C_Atlas_Disable();			//Disable Atlas

	LCD_write("BT Mesh Project", LCD_MESH_TEXT);

	/* Restore last smoke level from flash */
	printf("> Restoring last smoke level from flash storage...\n");
	uint8_t LastSmokeLevel;
	/* If smoke level was not found: */
	if ( Flash_Load_Byte(&LastSmokeLevel, FLASH_PS_KEY_SMOKELEVEL) == -2)
	{
		printf("> Smoke level was not found in flash storage, storing default value of 1...\n");
		Flash_Store_Byte(1, FLASH_PS_KEY_SMOKELEVEL);
	}
	/* Smoke level was restored: */
	else
	{
		printf("> Restored last saved smoke level: %u\n", LastSmokeLevel);
		if(LastSmokeLevel == 6)
		{
			LCD_write("Last:SMOKE DETECTED!", LCD_SMOKE_DETECTED);
		}
		/* Dislay on LCD */
		char SmokeLevel_String[15];
		snprintf(SmokeLevel_String, sizeof(SmokeLevel_String), "Last Smklvl: %u", LastSmokeLevel);
		LCD_write(SmokeLevel_String, LCD_SMOKE_LEVEL);
	}

	printf("> Boot-up complete! \n");


	while (1)
	{
		struct gecko_cmd_packet *evt = gecko_wait_event();
		bool pass = mesh_bgapi_listener(evt);

		if (pass)
		{
			handle_gecko_event(BGLIB_MSG_ID(evt->header), evt);
		}
	}
}

static void handle_gecko_event(uint32_t evt_id, struct gecko_cmd_packet *evt)
{
	uint16 Result;			//Stores the result of commands to check for errors

	switch (evt_id)
	{

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_system_boot_id:
		printf("\n**** EVENT: gecko_evt_system_boot_id: ****\n");

		/* Check if PB0 is held down to start flash reset */
		if (GPIO_PinInGet(gpioPortF, 6) == 0 )
		{
			printf("> PB0 held down => starting flash reset...\n");
			Flash_Reset();
		}
		else
		{
			struct gecko_msg_system_get_bt_address_rsp_t *Addr = gecko_cmd_system_get_bt_address();

			/* Setting unique Node name */
			Set_Node_name(&Addr->address);

			printf("> Initializing Mesh stack in node operation mode\n");
			printf("> Waiting for node initialized event...\n");

			/* Init OOB authentication */
		//	Result = gecko_cmd_mesh_node_init()->result;		//No OOB
			Result = gecko_cmd_mesh_node_init_oob(PUBLIC_KEY, OUTPUT_OOB, OUTPUT_NUMERIC, OUTPUT_SIZE, DONT_CARE, DONT_CARE, DONT_CARE)->result;

			if(Result != 0)
			{
				printf("> !!ERROR: Mesh node init failed!\n");
				printf("> !!Return code: 0x%x \n", Result);
			}
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_node_initialized_id:
		printf("\n**** EVENT: gecko_evt_mesh_node_initialized_id: *****\n");

		Result = gecko_cmd_mesh_generic_server_init()->result;
		if(Result != 0)
		{
			printf("> !!ERROR: Server init failed!\n");
			printf("> !!Return code: 0x%x \n", Result);
			break;
		}

		struct gecko_msg_mesh_node_initialized_evt_t *p_Result = (struct gecko_msg_mesh_node_initialized_evt_t *)&(evt->data);

		/* If node is already provisioned: */
		if (p_Result->provisioned)
		{
			LCD_write("Provisioned", LCD_PROV_STATUS);
			LCD_write(NO_FRIEND_TEXT, LCD_FRIEND_STATUS);

			printf("> Node is provisioned! Address:%x, ivi:%ld\n", p_Result->address, p_Result->ivi);

			My_Address = p_Result->address;
			Elem_Index = 0;   							//Index of primary element is zero

			/* Start LPN */
			SmokeAlarm_LPN_init();

			/* Enable timed sensor data collection */
			Result  = gecko_cmd_hardware_set_soft_timer(GET_SENSOR_DATA_TIME_IN_S, GET_SENSOR_DATA_TIMER_ID, GET_SENSOR_DATA_SINGLE_SHOT)->result;
			if (Result != 0)
			{
				printf("> !!ERROR: GET_SENSOR_DATA_TIMER set failure!\n");
				printf("> !!Return code 0x%X\n", Result);
			}
		}
		/* If node is not provisioned yet: */
		else
		{
			LCD_write("Unprovisioned", LCD_PROV_STATUS);
			LCD_write(NO_FRIEND_TEXT, LCD_FRIEND_STATUS);

			printf("> Node is unprovisioned\n");
			printf("> Starting unprovisioned beaconing...\n");
			gecko_cmd_mesh_node_start_unprov_beaconing(PB_GATT);   //enable GATT provisioning bearer
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_le_connection_opened_id:
		printf("\n**** EVENT: gecko_evt_le_connection_opened_id: *****\n");

		/* Increment the number of connections and store the connection handle */
		Num_Connections++;
		Connection_Handle = evt->data.evt_le_connection_opened.connection;
		printf("> Connection opened, handle: %u\n", Connection_Handle);

		LCD_write("Connected (GATT)", LCD_CONN_STATUS);

		/* Turn OFF LPN feature after GATT connection is opened */
		uint16 Result = gecko_cmd_mesh_lpn_deinit()->result;
		if(Result != 0)
		{
			printf("> !!ERROR: gecko_cmd_mesh_lpn_deinit() failed!\n");
			printf("> !!Return code: 0x%x \n", Result);
			return;
		}
		LCD_write("LPN off", LCD_LPN_STATUS);
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_le_connection_parameters_id:
		printf("\n**** EVENT: gecko_evt_le_connection_parameters_id: *****\n");
		printf("> Connection params:\n");
		printf(">\t interval: %u\n", evt->data.evt_le_connection_parameters.interval);
		printf(">\t timeout: %u\n", evt->data.evt_le_connection_parameters.timeout);
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_node_provisioning_started_id:
		printf("\n**** EVENT: gecko_evt_mesh_node_provisioning_started_id: *****\n");
		printf("> Started provisioning...\n");
		LCD_write("provisioning...", LCD_PROV_STATUS);
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_node_display_output_oob_id:
		printf("\n**** EVENT: gecko_evt_mesh_node_display_output_oob_id: *****\n");

		struct gecko_msg_mesh_node_display_output_oob_evt_t *Pass = (struct gecko_msg_mesh_node_display_output_oob_evt_t *)&(evt->data);

		/* Stores passkey in a string */
		char OOB_Passkey_String[3];
		uint8_t OOB_Passkey = Pass->data.data[Pass->data.len-1];

		__itoa(OOB_Passkey, OOB_Passkey_String, 10);

		/* Displays passkey on LCD and terminal */
		LCD_write("Prov. passkey:", LCD_PASSKEY_TEXT);
		LCD_write(OOB_Passkey_String, LCD_PASSKEY_NUM);
		printf("Pass: %d\n", Pass->data.data[Pass->data.len-1]);

//Debugging
//		printf("output_action: %d\n", Pass->output_action);
//		printf("output_size: %d\n", Pass->output_size);
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_node_provisioned_id:
		printf("\n**** EVENT: gecko_evt_mesh_node_provisioned_id: *****\n");
		/* Clear LCD from Prov. stuff */
		LCD_write("", LCD_PASSKEY_TEXT);
		LCD_write("", LCD_PASSKEY_NUM);

		LCD_write("Provisioned", LCD_PROV_STATUS);
		LCD_write(NO_FRIEND_TEXT, LCD_FRIEND_STATUS);

		printf("> Node is provisioned! Address:%x, ivi:%ld\n", p_Result->address, p_Result->ivi);

		My_Address = p_Result->address;
		Elem_Index = 0;   							//Index of primary element is zero

		/* Start LPN */
		printf("> Turning LPN on...\n");
		SmokeAlarm_LPN_init();
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_node_provisioning_failed_id:
		printf("\n**** EVENT: gecko_evt_mesh_node_provisioning_failed_id: *****\n");
		/* Clear LCD from Prov. stuff */
		LCD_write("", LCD_PASSKEY_TEXT);
		LCD_write("", LCD_PASSKEY_NUM);

		struct gecko_msg_mesh_node_provisioning_failed_evt_t *prov_Result = (struct gecko_msg_mesh_node_provisioning_failed_evt_t *)&(evt->data);

		LCD_write("Prov. failed", LCD_PASSKEY_TEXT);
		LCD_write("Try again", LCD_PASSKEY_NUM);

		printf("> !!ERROR: Provisioning failed!\n");
		printf("> !!Return code: 0x%x \n", prov_Result->result);

		/* Restart provisioning */
		printf("> Node is unprovisioned\n");
		printf("> Starting unprovisioned beaconing...\n");
		gecko_cmd_mesh_node_start_unprov_beaconing(PB_GATT);   //enable GATT provisioning bearer
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_lpn_friendship_established_id:
		printf("\n**** EVENT: gecko_evt_mesh_lpn_friendship_established_id: ****\n");
		printf("> Friendship established!\n");
		LCD_write(FRIEND_TEXT, LCD_FRIEND_STATUS);
		LCD_write("LPN ON", LCD_LPN_STATUS);

		/* If friendship is established, turn off FIND_FRIEND_TIMER */
		Result  = gecko_cmd_hardware_set_soft_timer(0, FIND_FRIEND_TIMER_ID, FIND_FRIEND_SINGLE_SHOT)->result;
		if (Result != 0)
		{
			printf("> !!ERROR: FIND_FRIEND_TIMER disable failure!\n");
			printf("> !!Return code 0x%X\n", Result);
		}

		/* Enable timed sensor data collection */
		Result  = gecko_cmd_hardware_set_soft_timer(GET_SENSOR_DATA_TIME_IN_S, GET_SENSOR_DATA_TIMER_ID, GET_SENSOR_DATA_SINGLE_SHOT)->result;
		if (Result != 0)
		{
			printf("> !!ERROR: GET_SENSOR_DATA_TIMER set failure!\n");
			printf("> !!Return code 0x%X\n", Result);
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_lpn_friendship_failed_id:
		printf("\n**** EVENT: gecko_evt_mesh_lpn_friendship_failed_id: ****\n");
		printf("> !!ERROR: Friendship failed\n");
		LCD_write("Friendship failed", LCD_FRIEND_STATUS);

		/* Try to find friend again after short delay */
		Result  = gecko_cmd_hardware_set_soft_timer(FIND_FRIEND_TIME_IN_S, FIND_FRIEND_TIMER_ID, FIND_FRIEND_SINGLE_SHOT)->result;
		if (Result != 0)
		{
			printf("> !!ERROR: FIND_FRIEND_TIMER set failure!\n");
			printf("> !!Return code 0x%X\n", Result);
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_lpn_friendship_terminated_id:
		printf("\n**** EVENT: gecko_evt_mesh_lpn_friendship_terminated_id: ****\n");
		printf("> Friendship terminated\n");

		LCD_write("Friend Disconn.", LCD_FRIEND_STATUS);

		if (Num_Connections == 0)
		{
			/* Try to find friend again after short delay */
			Result  = gecko_cmd_hardware_set_soft_timer(FIND_FRIEND_TIME_IN_S, FIND_FRIEND_TIMER_ID, FIND_FRIEND_SINGLE_SHOT)->result;
			if (Result != 0)
			{
				printf("> !!ERROR: FIND_FRIEND_TIMER set failure!\n");
				printf("> !!Return code 0x%X\n", Result);
			}
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_generic_server_state_changed_id:
		//printf("\n**** EVENT: gecko_evt_mesh_generic_server_state_changed_id: ****\n");

		//uncomment following line to get debug prints for each server state changed event
		//server_state_changed(&(evt->data.evt_mesh_generic_server_state_changed));

		//pass the server state changed event to mesh lib handler that will invoke
		//the callback functions registered by application
		//mesh_lib_generic_server_event_handler(evt);
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_le_connection_closed_id:
		printf("\n**** EVENT: gecko_evt_le_connection_closed_id: ****\n");

		printf("> Connection closed\n");
		printf("> Return code: 0x%X\n", evt->data.evt_le_connection_closed.reason);

		Connection_Handle = 0xFF;				//Reset connection handle

		if (Num_Connections > 0)
		{
			if (--Num_Connections == 0)
			{
				LCD_write("No connection", LCD_CONN_STATUS);

				printf("> Turning LPN on...\n");
				SmokeAlarm_LPN_init();
			}
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_mesh_node_reset_id:
		printf("\n**** EVENT: gecko_evt_mesh_node_reset_id: ****\n");
		Flash_Reset();
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/* These events silently discarded */
	case gecko_evt_le_gap_adv_timeout_id:
	//	printf("\n**** EVENT: gecko_evt_le_gap_adv_timeout_id: ****\n");
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_gatt_server_user_write_request_id:
			printf("\n**** EVENT: gecko_evt_gatt_server_user_write_request_id: ****\n");
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	case gecko_evt_hardware_soft_timer_id:
		printf("\n**** EVENT: gecko_evt_hardware_soft_timer_id: ****\n");

		switch (evt->data.evt_hardware_soft_timer.handle)
		{
			case FLASH_RESET_TIMER_ID:
				/* Reset the board */
				printf("> FLASH_RESET_TIMER_ID done => Resetting board...\n");
				gecko_cmd_system_reset(0);
				break;

			case FIND_FRIEND_TIMER_ID:
				/* Find friend again */
				printf("> FIND_FRIEND_TIMER_ID done => Finding friend...\n");
				Result = gecko_cmd_mesh_lpn_establish_friendship(0)->result;

				if (Result != 0)
				{
					printf("> !!ERROR: LPN establish friendship failed!\n");
					printf("> !!Return code: 0x%x \n", Result);

				}
				break;

			case GET_SENSOR_DATA_TIMER_ID:
				/* Gets data from the sensor */
				printf("> GET_SENSOR_DATA_TIMER_ID done => Gathering data from sensor...\n");

				LETIMER0_I2C_Atlas_Enable();			//Enable Atlas

				SLEEP_SleepBlockBegin(sleepEM2);		//Block EM2
				MAX30105_GetFIFOData(&Sensor_Circ_Buff);
				SLEEP_SleepBlockEnd(sleepEM2);			//Unblock EM2

				LETIMER0_I2C_Atlas_Disable();			//Disable Atlas

				SmokeLevelCheck(&Sensor_Circ_Buff);		//Check current smoke level
				break;

			case REINIT_LPN_TIMER_ID:
				/* Re-inits LPN after 1 min delay (because PB0 was pressed */
				printf("> REINIT_LPN_TIMER_ID done => Re-initializing LPN...\n");
				SmokeAlarm_LPN_init();
				break;

			default:
				printf("> !!ERROR: Unidentified TIMER_ID\n");
				break;
		}
		break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		case gecko_evt_system_external_signal_id:
			printf("\n**** EVENT: gecko_evt_system_external_signal_id: ****\n");

			/* PB0 Handler: if pressed, it will keep the node awake for 1 min */
			if( evt->data.evt_system_external_signal.extsignals & PB0_Flag )
			{
				CORE_AtomicDisableIrq();

				printf("> PB0 pressed: Keeping node awake for 1 min!\n");
				printf("> Any established friendship was terminated\n");

				uint16 Result = gecko_cmd_mesh_lpn_deinit()->result;
				if(Result != 0)
				{
					printf("> !!ERROR: gecko_cmd_mesh_lpn_deinit() failed!\n");
					printf("> !!Return code: 0x%x \n", Result);
					return;
				}

				LCD_write("LPN off", LCD_LPN_STATUS);
				LCD_write("Friend Disconn.", LCD_FRIEND_STATUS);

				/* Re-init LPN after 1 min delay */
				Result  = gecko_cmd_hardware_set_soft_timer(REINIT_LPN_TIME_IN_S, REINIT_LPN_TIMER_ID, REINIT_LPN_SINGLE_SHOT)->result;
				if (Result != 0)
				{
					printf("> !!ERROR: REINIT_LPN_ID set failure!\n");
					printf("> !!Return code 0x%X\n", Result);
				}

				evt->data.evt_system_external_signal.extsignals &= ~PB0_Flag;

				CORE_AtomicEnableIrq();

			}

			/* PB1 Handler: if pressed, it will print the contents of the circular buffer */
			if( evt->data.evt_system_external_signal.extsignals & PB1_Flag )
			{
				CORE_AtomicDisableIrq();

				CircBuff_PrintAll(&Sensor_Circ_Buff);

				evt->data.evt_system_external_signal.extsignals &= ~PB1_Flag;
				CORE_AtomicEnableIrq();
			}
			break;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	default:
//		printf("\n!!**** Event not found ****!!\n");
//		printf("> Header: 0x%08X\n", evt->header);
		break;
	}
}
