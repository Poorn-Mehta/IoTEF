#ifndef LCD_DRIVER_H_
#define LCD_DRIVER_H_

/*
 * THIS LIBRARY WAS TAKEN FROM THE CLASS CANVAS FOLDER. I MODIFIED AND ADDED FUNCTIONS.
 * IT WAS NOT WRITTEN BY KHALID ALAWADHI, ONLY MODIFIED.
 */

#include "hal-config.h"

#if (HAL_SPIDISPLAY_ENABLE == 1)

#include "bg_types.h"

#define LCD_ROW_MAX        13    /* total number of rows used */
#define LCD_ROW_LEN        32    /* up to 32 characters per each row */

//char *header - a C string that contains the header which is persistent. For ex for a BLE Server -> header = "BLE SERVER"
void LCD_init();

//char *str  - the C string you want to display in the row number
void LCD_write(char *str, uint8 row);


/**************************************************************************************************************
 * USAGE: This function will clear all the text on the LCD display (if any)
 *
 * PARAMETERS:
 *            - None
 *
 * RETURNS: NONE
 *
 **************************************************************************************************************/
void LCD_Clear();


#endif /* HAL_SPIDISPLAY_ENABLE */

#endif /* LCD_DRIVER_H_ */
