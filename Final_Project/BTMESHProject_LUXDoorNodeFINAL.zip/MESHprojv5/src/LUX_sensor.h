/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 11-09-2018
 *
 * FILE: LUX_sensor.h
 *
 * DESCRIPTION:  header file for using the TSL2561 Lumosity sensor,
 * sparkfun part number: SEN-12055
 */

#ifndef SRC_LUX_SENSOR_H_
#define SRC_LUX_SENSOR_H_

#include "main.h"
#include "myBG_i2cdriver.h"
#include "lcd_driver.h"
#include <math.h>

#define LUX_SENSOR_ADDR				0x39			//default address, no solder jumpers on sensor

#define ADDR_CONTROL				0x00
#define ADDR_TIMING					0x01
#define ADDR_THRESHLOWLOW			0x02
#define ADDR_THRESHLOWHIGH			0x03
#define ADDR_THRESHHIGHLOW			0x04
#define ADDR_THRESHHIGHHIGH			0x05
#define ADDR_INTERRUPT				0x06
#define ADDR_CRC					0x08
#define ADDR_ID						0x0A
#define ADDR_DATA0LOW				0x0C
#define ADDR_DATA0HIGH				0x0D
#define ADDR_DATA1LOW				0x0E
#define ADDR_DATA1HIGH				0X0F

#define CMD_REG_CMD					(1<<7)		//should be bit 7 in the command register
#define CMD_REG_CLEAR				(1<<6)		//clears pending interrupt, write 1 to clear, self clearing
#define CMD_REG_WORD				(1<<5)		//SMB R/W word protocol
#define CMD_REG_BLOCK				(1<<4)		//block R/W protocol

#define CTRL_REG_ON					0x03
#define CTRL_REG_OFF				0x00

#define INTER_CTRL_DISABLE			(0x00 << 4)//0x00		//writing all zeros to remove persistence period as well
#define INTER_CTRL_LEVEL			(0x01 << 4)


#define INTER_PERSIS_EVERY			0x00
#define INTER_PERSIS_ANY			0x01
#define INTER_PERSIS_2PERIOD		0x02
#define INTER_PERSIS_3PERIOD		0x03
#define INTER_PERSIS_4PERIOD		0x04
//ABOVE VALUES CAN EXTEND TO 15 INTEGRATION PERIODS OUT OF RANGE

/*
 * The below alarm levels set the how the calculated LUX values are divided up
 * ranging between dark and very bright
 */
#define LUX_ALARM_LEVEL00			4			//roughly desk working space at kitchen table
#define LUX_ALARM_LEVEL01			20			//working light between 4 and 20, varies
#define LUX_ALARM_LEVEL02			200			//between 200 and 800 is varying level of flashlight distance
#define LUX_ALARM_LEVEL03			250
#define LUX_ALARM_LEVEL04			300
#define LUX_ALARM_LEVEL05			400
#define LUX_ALARM_LEVEL06			600
#define LUX_ALARM_LEVEL07			700
#define LUX_ALARM_LEVEL08			800
#define LUX_ALARM_LEVEL09			900			// phone flashlight close, but not close enough to saturate
#define LUX_ALARM_LEVEL10			1000		//have not been able to obtain, need to test in sunlight

/*
 * These values are sent to the network and indicate to the moisture sensor node
 * the current level of LUX hitting the sensor
 */
#define LUX_ALARM_0					0x00
#define LUX_ALARM_1					0x01
#define LUX_ALARM_2					0x02
#define LUX_ALARM_3					0x03
#define LUX_ALARM_4					0x04
#define LUX_ALARM_5					0x05
#define LUX_ALARM_6					0x06
#define LUX_ALARM_7					0x07
#define LUX_ALARM_8					0x08
#define LUX_ALARM_9					0x09
#define LUX_ALARM_10				0x0a

/*
 * working at desk: lux = ~6.5
 * thumb over sensor: lux = ~.11
 * phone flashlight just about touching sensor: lux = ~11.1
 * phone light about an inch away: lux ~ 650 to 860
 */

/*
 * values for the interrupt threshold high and low registers
 */
#define INTER_THRESH_LOWLOW			0x00
#define INTER_THRESH_LOWHIGH		0x00
#define INTER_THRESH_HIGHLOW		0x00
#define INTER_THRESH_HIGHHIGH		0x05

/*
 * gets the current LUX value from i2c sensor
 */
float getLUXreading(void);

/*
 * initializes LUX sensor with following parameters
 * gain: 16x
 * integration time: 403ms (default setting)
 * interrupt settings:  level (when LUX is outside upper and lower values)
 * 						value must be outside given values for 4 integration periods(0100).
 */

uint8_t LUX_sensor_init(void);

/*
 * turns LUX sensor on and off
 * 0x03 for on / 0x00 for off when written to control register
 * returns value when read of 0x03 when value of 0x03 is written to register
 */

uint8_t LUX_onoff(uint8_t onoff);

/*
 * accepts ch0 and ch1 values and calculates the LUX value
 */
float calcLUXvalue (uint16_t ch0, uint16_t ch1);

/*
 * accepts a float LUX value and produces a LUX alarm level
 * between 0 and 10.
 */
uint16_t chose_LUX_alarm_level(float current_LUX_value);

/*
 * provide communication status of the LUX sensor
 * returns 0 if no issues, returns a 1 if error
 * leaves sensor in the OFF state.  must be turned on when ready to be used,
 * either in the boot / already provisioned event or just provisioned event
 */
uint8_t LUX_sensor_check(void);

/*
 * display the current setting for the LUX sensor
 */
void display_LUX_settings(void);

/*
 * function is called in the soft timer event
 */
void event_soft_timer_GETLUXVALUE(void);

#endif /* SRC_LUX_SENSOR_H_ */
