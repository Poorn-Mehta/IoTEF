/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 11-09-2018
 *
 * FILE: LUX_sensor.c
 *
 * DESCRIPTION:  function definitions for using the TSL2561 Lumosity sensor,
 * sparkfun part number: SEN-12055
 */

#include "LUX_sensor.h"

uint8_t LUX_sensor_init(void)
{
	printf_counter++;
	printf("[%d] : Default values set / untouched\n",printf_counter);

	return 0;
}

void display_LUX_settings(void)
{
	uint8_t timing_register = myBG_i2cRead(LUX_SENSOR_ADDR, ADDR_TIMING, CMD_REG_CMD);
	printf_counter++;
	printf("[%d] : Timing Register Value: 0x%02x\n",printf_counter, timing_register);
}

uint8_t LUX_onoff(uint8_t onoff)
{
	/*
	 * sends turn on command and then reads value from sensor
	 * value returned from sensor should be 0x03, this value
	 * confirms communication
	 */
	uint8_t read_data = 0;
	if(onoff == 1)
	{
		myBG_i2cWrite(LUX_SENSOR_ADDR, ADDR_CONTROL, CMD_REG_CMD, CTRL_REG_ON);
		read_data = myBG_i2cRead(LUX_SENSOR_ADDR,ADDR_CONTROL, CMD_REG_CMD);
		return read_data;
	}
	else if (onoff == 0)
	{
		myBG_i2cWrite(LUX_SENSOR_ADDR, ADDR_CONTROL, CMD_REG_CMD, CTRL_REG_OFF);
		return 0;
	}
	else
	{
		return 1;
	}
}

uint8_t LUX_sensor_check(void)
{
	//returned value for turning on / off sensor
	uint8_t sensor_confirm = 0;
	LUX_onoff(0);
	sensor_confirm = LUX_onoff(1);
	if(sensor_confirm == 0x03)
	{
	  return 0;
	}
	else
	{
	  return 1;
	}
}

float calcLUXvalue (uint16_t ch0, uint16_t ch1)
{
	/*
	 * LUX calculation was taken from the TSL2560, TSL2561 Light-to-Digital
	 * Converter datasheet produced by TAOS, edition TAOS059N - March 2009
	 * Page 23, under the heading "Calculating Lux".
	 */
	float ratio = 0;
	ratio = (float)ch1/(float)ch0;

	float LUX_value = 0;
	if((ratio > 0) && (ratio <= 0.50))
	{
		LUX_value = (0.0304 * ch0) - (0.062 * ch0* (pow(ratio,1.4)));
	}

	if((ratio > 0.50) && (ratio <= 0.61))
	{
		LUX_value = (0.0224 * ch0) - (0.031 * ch1);
	}
	if((ratio > 0.61) && (ratio <=0.80))
	{
		LUX_value = (0.0128*ch0) - (0.0153 * ch1);
	}
	if((ratio > 0.80) && (ratio <=1.30))
	{
		LUX_value = (0.00146 * ch0) - (0.00112*ch1);
	}
	if(ratio > 1.30)
	{
		LUX_value = 0;
	}
	return LUX_value;
}

float getLUXreading(void)
{
	uint8_t data0low, data0high, data1low, data1high;
	uint16_t ch0, ch1;
	float final_LUX_value = 0;

	//this will get the first byte of the value
	data0low = myBG_i2cRead(LUX_SENSOR_ADDR,ADDR_DATA0LOW, CMD_REG_CMD);
	data0high = myBG_i2cRead(LUX_SENSOR_ADDR,ADDR_DATA0HIGH, CMD_REG_CMD);
	data1low = myBG_i2cRead(LUX_SENSOR_ADDR,ADDR_DATA1LOW, CMD_REG_CMD);
	data1high = myBG_i2cRead(LUX_SENSOR_ADDR,ADDR_DATA1HIGH, CMD_REG_CMD);

	ch0 = (data0high << 7) | data0low;
	ch1 = (data1high << 7) | data1low;
	final_LUX_value = calcLUXvalue(ch0,ch1);
	sprintf(LCD_array_store, "LUX: %02f",final_LUX_value);
	LCD_write(LCD_array_store, LCD_ROW_12);
	return final_LUX_value;
}


uint16_t chose_LUX_alarm_level(float current_LUX_value)
{
	uint16_t LUX_level_publish = 0;

	if(current_LUX_value <= LUX_ALARM_LEVEL00)
	{
		LUX_level_publish = LUX_ALARM_0;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL00) && (current_LUX_value<=LUX_ALARM_LEVEL01))
	{
		LUX_level_publish = LUX_ALARM_1;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL01) && (current_LUX_value<=LUX_ALARM_LEVEL02))
	{
		LUX_level_publish = LUX_ALARM_2;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL02) && (current_LUX_value<=LUX_ALARM_LEVEL03))
	{
		LUX_level_publish = LUX_ALARM_3;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL03) && (current_LUX_value<=LUX_ALARM_LEVEL04))
	{
		LUX_level_publish = LUX_ALARM_4;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL04) && (current_LUX_value<=LUX_ALARM_LEVEL05))
	{
		LUX_level_publish = LUX_ALARM_5;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL05) && (current_LUX_value<=LUX_ALARM_LEVEL06))
	{
		LUX_level_publish = LUX_ALARM_6;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL06) && (current_LUX_value<=LUX_ALARM_LEVEL07))
	{
		LUX_level_publish = LUX_ALARM_7;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL07) && (current_LUX_value<=LUX_ALARM_LEVEL08))
	{
		LUX_level_publish = LUX_ALARM_8;
	}
	if((current_LUX_value>LUX_ALARM_LEVEL08) && (current_LUX_value<=LUX_ALARM_LEVEL09))
	{
		LUX_level_publish = LUX_ALARM_9;
	}
	if(current_LUX_value > LUX_ALARM_LEVEL09)
	{
		LUX_level_publish = LUX_ALARM_10;
	}

	return LUX_level_publish;
}

void event_soft_timer_GETLUXVALUE(void)
{
	gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(LUX_GET_INTERVAL),TIMER_ID_LUX_VALUE_GET,1);
	static uint8_t LUX_group_alarm_counter = 0;

	current_lux_value = 0;
	LUX_alarm_level = 0;
	static uint16_t previous_LUX_alarm_level;

	current_lux_value = getLUXreading();
	LUX_alarm_level = chose_LUX_alarm_level(current_lux_value);
	printf_counter++;
	printf("[%d] : LUX =  %.*f || LUX Alarm Level = %d\n", printf_counter, 2,current_lux_value,LUX_alarm_level);

	/*
	 * checks to see if the current alarm level is less than stated.  if it is the group alarm
	 * timer continues to be reset.  Once the alarm level is above stated, then the timer will not
	 * be reset and will be allowed to timeout, publishing a group message.  if at any time the
	 * alarm level drops below stated, the timer will be reset and initial condition will take affect
	 * **LIMIT is set in main.h
	 */
	if((LUX_alarm_level >= GROUP_MESSAGE_LIMIT)  || (LUX_group_alarm_counter >= GROUP_MESSAGE_LIMIT))
	{
		LUX_group_alarm_counter++;
		if(LUX_group_alarm_counter >= 4)			//4 get_LUX cycles
		{
			printf_counter++;
			printf("[%d] : **********Group Message Published**********\n",printf_counter);
			LCD_write("GROUP ALARM!!",LCD_ROW_9);
			gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(DISPALY_ALARM_LCD),TIMER_ID_DISPLAY_ALARM_LCD,1);
			current_state_generic_level.level.level = 0x7fff;
			mesh_lib_result = mesh_lib_generic_server_update(MESH_GENERIC_LEVEL_SERVER_MODEL_ID, _primary_elem_index,
											&current_state_generic_level, 0,0);
	    	mesh_lib_generic_server_publish(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
	    			_primary_elem_index, mesh_generic_state_level);
			current_state_generic_level.level.level = LUX_alarm_level;
			mesh_lib_generic_server_update(MESH_GENERIC_LEVEL_SERVER_MODEL_ID, _primary_elem_index,
			        											&current_state_generic_level, 0,0);
		}
	}

	if(previous_LUX_alarm_level != LUX_alarm_level)					//only publishes a LUX Level message when value has changed
	{
		current_state_generic_level.level.level = LUX_alarm_level;
		mesh_lib_result = mesh_lib_generic_server_update(MESH_GENERIC_LEVEL_SERVER_MODEL_ID, _primary_elem_index,
										&current_state_generic_level, 0,0);

    	mesh_lib_generic_server_publish(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,
    			_primary_elem_index, mesh_generic_state_level);
    	printf_counter++;
    	printf("[%d] : **********New LUX Alarm Level Published**********\n",printf_counter);
    	LCD_write("LUX Level Alarm!!",LCD_ROW_9);
    	gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(DISPALY_ALARM_LCD),TIMER_ID_DISPLAY_ALARM_LCD,1);
	}

	if(LUX_alarm_level < GROUP_MESSAGE_LIMIT)
	{
		LUX_group_alarm_counter = 0;
	}

	previous_LUX_alarm_level = LUX_alarm_level;				//saving for next iteration to compare
}
