/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 11-09-2018
 *
 * FILE: main.h
 *
 * DESCRIPTION:  header file for main.c.  The below description of all nodes in our project
 * is described below.  Description only written by Poorn Mehta, a group member.
 */

/*****************************************************************************************************
 * Owner: Poorn Mehta (Poorn.Mehta@Colorado.EDU)
 * Date Last Modified: 12/06/2018
 *>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>NODE OVERVIEW<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
 * This node is part of a project which uses Bluetooth mesh network to share important information
 * obtained from variety of sensors, and to act upon it.
 *
 * This node was tested along with 3 other nodes - all using Generic Level Servers
 * Due to limitation of the provisioner made available by Silicon Labs, only one model is used
 * CAUTION - This node uses the standard model in non standard model to achieve full functionality
 * This node works as the central device of the star network being formed (using mesh stack)
 *
 * Following are the nodes and their functionality
 *
 * NODE 1 - Moisture - Low Power <Generic Level Server> | Persistent Data:
 * 			Measure moisture level using a specific sensor. Sets alarm threshold based on the Lux value
 * 			received from another node which uses Lux sensor, and communicates to this <moisture> node
 * 			via central node. When the moisture level crosses the threshold (which is dynamically
 * 			determined using the light level presented), it raises the alarm - which is based on central node.
 *
 * 			-> PUBLISHES 0x7FFF (highest value for int8_t - which is the value type of the model being used)
 * 				to the ALARM GROUP as a mean to convey the message that the moisture alarm is raised
 * 			-> Communicates to Central node through UNICAST messaging, when the central node uses a
 * 				client_set on this node. The central node basically just relays the Lux level (also referred
 * 				to as Threshold level in the present code) - without knowing how to use or interpret that.
 * 				That task is solely upto the Moisture node. Lux node and Moisture nodes should agree and
 * 				establish a method to effectively communicate with each other
 * 			-> PUBLISHES the actual moisture level when the Alarm is OFF.
 *
 * Node 2 - Lux/Door - Friend <Generic Level Server> | Persistent Data:
 * 			Measures the intensity of light and converts it to Lux. Additionally, it (ideally) controls
 * 			a secured door using magnetic lock, which is driven by central node through fingerprint
 * 			sensor implemented on it. Moreoever, it has the capability to send an alarm - either indicating
 * 			that the door was forcefully opened somehow (by implementing special sensor) - or when the light
 * 			is 'too' bright. The functionality can be easily set and determined by the node. However, other
 * 			nodes in network need to know it in order to correctly interpret/use the information provided.
 *
 * 			-> PUBLISHES 0x7FFF to the ALARM GROUP to raise an alarm.
 * 			-> PUBLISHES the scaled Lux level (or threshold level) periodically when the alarm is OFF
 * 			-> Communicates to Central through UNICAST messaging - in both ways. Central node polls
 * 				this node at every fixed interval (5 seconds now) using client_get() to receive the
 * 				Lux/Threshold level values.
 * 			-> Central node sends this node 0x7FFF when it recognizes a fingerprint that was stored in the
 * 				database as the one belonging to a person authorized to open the secure door. This is done
 * 				by central node using client_set() on this Lux/Door node.
 *
 * Node 3 - Smoke - Low Power <Generic Level Server> | Persistent Data:
 * 			Measures the smoke level of the entity that it is configured for, and raises the alarm when
 * 			it crosses the predetermined threshold. Even this LPN's threshold can be updated dynamically,
 * 			similarly to that of the Moisture node, however it wasn't included due to time restrictions.
 * 			Besides Alarm, this node updates the scaled down smoke level value which is read from Central
 * 			node on a button press.
 *
 * 			-> PUBLISHES 0x7FFF to the ALARM GROUP to notify the group about high smoke level
 * 			-> Updates server with scaled smoke level, which is then made available to central node through
 * 				mesh stack. This uses UNICAST messaging since the central node uses client_get()
 *
 * Node 4 - Fingerprint/Central  - Friend - <Generic Level Client> | Persistent Data: Alarm Status
 * 			Subscribed to the Alarm Group. Sounds a buzzer whenever any Alarm ON is published to the group.
 * 			Displays the combination of nodes which has raise the Alarm before it was manually cleared by
 * 			presseing button 0 (PB0 - Push Button 0). Stores is to the flash - which is useful if the alarm
 * 			was on and the node went through a power cycle. On button 1 press, it gets smoke level from
 * 			Smoke node using UNICAST client get(). It also integrates fingerprint scanner to which, new
 * 			fingerprints can be added by a few means. When a stored/valid fingerprint is pressed, the node
 * 			sends the command of Door Open to Lux/Door node by using client_set() on that node, and with
 * 			the value of 0x7FFF. This node polls Lux/Door node for new scaled Lux/Threshold value. If it
 * 			is different from the last one, then relays it to Moisture node.
 *
 * 			-> SUBSCRIBES to the group. Services the Alarm.
 * 			-> If any node publishes any other value than the ALARM ON (0x7FFF) then treats is uniquely.
 * 				Moisture node's publishes are treated as Mositure Level absolute values, Lux/Door node's
 * 				publishes are treated as scaled Lux level. Smoke node's publishes are treated as scaled
 * 				Smoke Level.
 * 			-> Communicates to all 3 nodes using UNICAST messaging.
 * 				- To/From Smoke - Gets smoke level on PB1 press (client_get()).
 * 				- To/From Lux/Door - Gets lux level periodically (client_get()). Sets Door state to Open (client_set()).
 * 				- To/From Moisture - Sets threshold level (a.k.a. scaled Lux level) if it is different from last received
 * 										lux level.
 *****************************************************************************************************/

#ifndef SRC_MAIN_H_
#define SRC_MAIN_H_

/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

/* Board headers */
#include "init_mcu.h"
#include "init_board.h"
#include "init_app.h"
#include "ble-configuration.h"
#include "board_features.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include <gecko_configuration.h>
#include "mesh_generic_model_capi_types.h"
#include "mesh_lighting_model_capi_types.h"
#include "mesh_lib.h"
#include <mesh_sizes.h>

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#include <em_gpio.h>
#include "em_core.h"
#include <inttypes.h>

/* Device initialization header */
#include "hal-config.h"
#include "retargetserial.h"
#include "lcd_driver.h"

#include "gpiointerrupt.h"

#if defined(HAL_CONFIG)
#include "bsphalconfig.h"
#else
#include "bspconfig.h"
#endif

#include <bg_errorcodes.h>

/*
 * setting the number of available models
 */
#define NUM_MODELS_AVAILABLE		4

//values used to choose the bearer level
#define BEARER_PB_ADV			0x01
#define BEARER_PB_GATT			0x02
#define BEARER_BOTH				0x03

/*value for initializing OOB authentication
*see gecko_cmd_mesh_node_init_oob function for parameter details
*/
#define PUBLIC_KEY_NONE 		(0 << 0)
#define PUBLIC_KEY_USED			(1 << 0)

#define AUTH_METH_NONE			(1 << 0)
#define AUTH_METH_STATIC		(1 << 1)
#define AUTH_METH_OUTPUT		(1 << 2)
#define AUTH_METH_OUTPUT_OOB	(1 << 3)

#define OUTPUT_BLINK			(1 << 0)
#define OUTPUT_BEEP				(1 << 1)
#define OUTPUT_NUMERIC			(1 << 3)
#define OUTPUT_ALPHA			(1 << 4)

#define OUT_SIZE_NA				0x00
#define OUT_SIZE_1				0x01
#define OUT_SIZE_2				0x02
#define OUT_SIZE_4				0x04
#define OUT_SIZE_6				0x06

#define INPUT_NONE				(0 << 0)
#define INPUT_NUM				(1 << 2)

#define INPUT_SIZE_NA			(0 << 0)
#define INPUT_SIZE_1			0x01
#define INPUT_SIZE_2			(1 << 2)

#define DATA_LOC_NONE			(0 << 0)
#define DATA_LOC_OTHER			(1 << 0)
#define DATA_LOC_URI			(1 << 1)
#define DATA_LOC_NUMBER			(1 << 5)
#define DATA_LOC_STRING			(1 << 6)
#define DATA_LOC_DEVICE			(1 << 15)

/*
 * Timer defines and constants
 * Defines for TIMER_CLK_FREQ AND TIMER_MS_2_TIMERTICK below are taken
 * from the SiLabs Light Mesh example
 */
#define TIMER_CLK_FREQ ((uint32_t)32768)								/** Timer Frequency used. */
#define TIMER_MS_2_TIMERTICK(ms) ((TIMER_CLK_FREQ * ms) / 1000)		/** Convert msec to timer ticks. */

//software timer IDs
#define TIMER_ID_LUX_VALUE_GET			50
#define TIMER_ID_FACTORY_RESET			55
#define TIMER_ID_DOOR_OPERATION			65
#define TIMER_ID_DISPLAY_ALARM_LCD		66

/*
 * timing parameters for software timers above
 * all values are in milli seconds
 */
#define LUX_GET_INTERVAL			1000
#define RESET_WAIT_INTERVAL			1000
#define LUX_INTERRUPT_LED_OFF		500
#define GROUP_ALARM_TIMEOUT			(4*LUX_GET_INTERVAL)
#define DOOR_OPEN					5000
#define DISPALY_ALARM_LCD			3000

#define GROUP_MESSAGE_LIMIT			LUX_ALARM_6		//sets the limit to when above LUX level for long enough, will send a group alarm

/*
 * Base address for persistent data
 * This address can be used to access the remaining data storage locations
 * Range is from 0x4000 to 0x407F with each key 56 bytes
 */
#define PERSIS_DATA_BASE_ADDR			0x4000

/*
 * GLOBAL VARIABLES
 */
uint16_t LUX_alarm_level;							//value for current LUX alarm level, from chose_LUX_alarm_level FXN
uint16_t _primary_elem_index;						//For indexing elements of the node, primary = 0
uint16_t result;									//stores result value from all commands
char LCD_array_store[30];							//stores strings for all sprintf functions for LCD
uint8_t conn_handle;								//stores value of last connection handle
errorcode_t mesh_lib_result;						//variable to store result of model update

typedef struct persist_data							//data type for information to be stored in persistent data flash
{
	uint8_t num_door_open;
	float lux_value;
}persist_data;

persist_data my_stored_data;						//used for persistent data storage on flash, see struct above
float current_lux_value;							//stores current LUX value obtained from calculations
int printf_counter;									//when using terminal printing, count value for each line

struct mesh_generic_state current_state_generic_level;

#endif /* SRC_MAIN_H_ */
