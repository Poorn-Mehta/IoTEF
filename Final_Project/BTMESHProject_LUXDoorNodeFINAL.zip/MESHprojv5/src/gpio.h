/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 11-09-2018
 *
 * FILE: gpio.h
 *
 * DESCRIPTION:  header file for GPIO pins, Blue Gecko
 *
 * PLEASE NOTE!: This file was provided by Professor Keith Graham and used and
 * modified with permission for this class.
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "main.h"
#include <em_gpio.h>
#include "em_cmu.h"

//***********************************************************************************
// defined files
//***********************************************************************************

// LED0 pin is
#define	LED0_port			gpioPortF
#define LED0_pin			4
#define LED0_default		false 	// off
// LED1 pin is
#define LED1_port			gpioPortF
#define LED1_pin			5
#define LED1_default		false	// off

//Push Button PB0
#define PB0_PORT			gpioPortF
#define PB0_PIN				6
#define PB0_DEFAULT			true	//on

//Push Button PB1
#define PB1_PORT			gpioPortF
#define PB1_PIN				7
#define PB1_DEFAULT			true	//on

//GPIO used for interrupt signal for LUX sensor
//Connected to EXT_HEADER pin 7, bottom header P4
#define PD10_PORT			gpioPortD
#define PD10_PIN			10
#define PD10_DEFAULT		true

//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************
void gpio_init(void);


