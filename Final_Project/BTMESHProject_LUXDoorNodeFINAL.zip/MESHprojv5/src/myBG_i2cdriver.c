/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 9-19-2018
 *
 * FILE: i2cdriver.c
 *
 * DESCRIPTION:  driver functions for the i2c on the Blue Gecko
 */

//***********************************************************************************
// Include files
//***********************************************************************************

#include <src/myBG_i2cdriver.h>


void i2cInit(void)
{
	CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFXO);		//selecting the HFXO clock
	CMU_ClockEnable(cmuClock_HFPER, true);					//enable the perif clock
	CMU_ClockEnable(cmuClock_I2C0, true);				//enables clock to i2c perif

	I2C0->ROUTEPEN =  I2C_ROUTEPEN_SDAPEN | I2C_ROUTEPEN_SCLPEN;
	I2C0->ROUTELOC0 |= I2C_ROUTELOC0_SCLLOC_LOC14;		//location 14 for SCL
	I2C0->ROUTELOC0 |= I2C_ROUTELOC0_SDALOC_LOC16;		//SDA location 16


	I2C_Init_TypeDef isqrCBus = I2C_INIT_DEFAULT;
	isqrCBus.freq = I2C_FREQ_FAST_MAX;
	isqrCBus.clhr = i2cClockHLRFast;
	I2C_Init(I2C0,&isqrCBus);

	I2C0->IFC = 0x0007FFCF;					//write 1's to all locations to clear all interrupts

	NVIC_EnableIRQ(I2C0_IRQn);
}

void tempSenseEnable(void)
{
	GPIO_PinModeSet(I2C_ENABLE_PORT, I2C_ENABLE_pin, gpioModePushPull, 1); 		//turning on the sensor
	//my_timer1_init();
	TIMER1->CMD = TIMER_CMD_START;
}

void i2cLoadPowerOn(void)
{
	//prescaler for i2c and timer1 are selected at the same time, reset here after timer1 has used it
	CMU->HFPERPRESC = CMU_HFPERPRESC_PRESC_DEFAULT;


	GPIO_PinModeSet(I2C0_SCL_PORT, I2C0_SCL_pin, gpioModeWiredAnd, 1);
	GPIO_PinModeSet(I2C0_SDA_PORT, I2C0_SDA_pin, gpioModeWiredAnd, 1);

	for (int i=0; i<9; i++)
	{
		GPIO_PinModeSet(I2C0_SCL_PORT,I2C0_SCL_pin,gpioModeWiredAnd, 0);
		GPIO_PinModeSet(I2C0_SCL_PORT,I2C0_SCL_pin,gpioModeWiredAnd, 1);
	}

	//reset the I2C bus to synch the perifs.
	if(I2C0->CMD & I2C_STATE_BUSY)
	{
		I2C0->CMD |= I2C_CMD_ABORT;
	}
}
void i2cLoadPowerOff(void)
{
	//removes SCL and SDA from bus
	GPIO_PinModeSet(I2C0_SCL_PORT, I2C0_SCL_pin, gpioModeDisabled, 0);
	GPIO_PinModeSet(I2C0_SDA_PORT, I2C0_SDA_pin, gpioModeDisabled, 0);

	//disables the temp sensor
	//GPIO_PinOutClear(I2C_ENABLE_PORT, I2C_ENABLE_pin);
	/*
	 * when using the LCD in conjunction with the temp sensor, issues
	 * arise since they are both connected to the same enable/disable
	 * pins.  Commenting out the above prevents the LCD from being
	 * cleared and ownership being transfered
	 */
}


void myBG_i2cWrite(uint8_t slave_addr, uint8_t reg_addr, uint8_t cmd, uint8_t data)
{
	CORE_AtomicDisableIrq();
	//add checks for NACKs, not only ACK, return 1 or 0 depending on which is received
	uint8_t addr_write = 0;
	i2cLoadPowerOn();

	//I2C0->CMD = I2C_CMD_START;				//sends start start condition

	addr_write = (slave_addr<<1) | 0;
	I2C0->TXDATA = addr_write;				//sends slave address and write operation
	I2C0->CMD = I2C_CMD_START;


	//waiting for an ACK
	while((I2C0->IF & I2C_IF_ACK) == 0);
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->TXDATA = (cmd | reg_addr);						//send command code
	while((I2C0->IF & I2C_IF_ACK) == 0);
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->TXDATA = data;					//send data that should be written to register specified in cmd
	while((I2C0->IF & I2C_IF_ACK) == 0);	//wait for ack
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->CMD = I2C_CMD_NACK;
	I2C0->CMD = I2C_CMD_STOP;				//send stop condition

	CORE_AtomicEnableIrq();
}

void myBG_i2cWriteWORD(uint8_t slave_addr, uint8_t reg_addr, uint8_t cmd, uint8_t dataHigh, uint8_t dataLow)
{
	CORE_AtomicDisableIrq();
	//add checks for NACKs, not only ACK, return 1 or 0 depending on which is received
	uint8_t addr_write = 0;
	i2cLoadPowerOn();

	//I2C0->CMD = I2C_CMD_START;				//sends start start condition

	addr_write = (slave_addr<<1) | 0;
	I2C0->TXDATA = addr_write;				//sends slave address and write operation
	I2C0->CMD = I2C_CMD_START;


	//waiting for an ACK
	while((I2C0->IF & I2C_IF_ACK) == 0);
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->TXDATA = (cmd | reg_addr);						//send command code
	while((I2C0->IF & I2C_IF_ACK) == 0);
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->TXDATA = dataHigh;					//send data that should be written to register specified in cmd
	while((I2C0->IF & I2C_IF_ACK) == 0);	//wait for ack
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->TXDATA = dataLow;
	while((I2C0->IF & I2C_IF_ACK) == 0);	//wait for ack
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->CMD = I2C_CMD_NACK;
	I2C0->CMD = I2C_CMD_STOP;				//send stop condition

	CORE_AtomicEnableIrq();
}

uint8_t myBG_i2cRead(uint8_t slave_addr, uint8_t reg_addr, uint8_t cmd)
{
	CORE_AtomicDisableIrq();
	//add checks for NACKs, not only ACK, return 1 or 0 depending on which is received
	uint8_t addr_write = 0;
	uint8_t RXdata_received = 0;

	addr_write = (slave_addr<<1) | 0;
	I2C0->TXDATA = addr_write;				//sends slave address and write operation
	I2C0->CMD = I2C_CMD_START;				//sends start condition

	while((I2C0->IF & I2C_IF_ACK) == 0);	//wait for ACK
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->TXDATA = (cmd | reg_addr);						//send command code
	while((I2C0->IF & I2C_IF_ACK) == 0);	//wait for ACK
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	I2C0->CMD = I2C_CMD_START;				//resend start condition

	addr_write = (slave_addr<<1) | 1;
	I2C0->TXDATA = addr_write;				//sends slave address and read operation

	while((I2C0->IF & I2C_IF_ACK) == 0);	//wait for ACK
	I2C0->IFC |= I2C_IFC_ACK;				//clear ack

	while((I2C0->IF & I2C_IF_RXDATAV) == 0);	//waiting for information to be present on RX register

	RXdata_received = I2C0->RXDATA;			//save received value

	I2C0->CMD = I2C_CMD_NACK;				//send nack to slave, complete transmission, only RX 1 byte

	I2C0->CMD = I2C_CMD_STOP;				//sending stop condition
	CORE_AtomicEnableIrq();

	return RXdata_received;
}
