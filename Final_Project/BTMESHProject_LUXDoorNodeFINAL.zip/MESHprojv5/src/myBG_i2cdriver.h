/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 9-12-2018
 *
 * FILE: i2cdriver.h
 *
 * DESCRIPTION:  header file for driver functions for the i2c on the Blue Gecko
 */


//***********************************************************************************
// Include files
//***********************************************************************************

#ifndef myBG_i2cdriver_H_
#define myBG_i2cdriver_H_

#include "main.h"
#include "em_cmu.h"
#include <em_i2c.h>
#include <em_gpio.h>
#include <em_core.h>

//***********************************************************************************
// defined files
//***********************************************************************************

//***********************************************************************************
// global variables
//***********************************************************************************

/*****GPIO Definitions for I2C********/
#define I2C0_SCL_PORT		gpioPortC
#define I2C0_SCL_pin		10

#define I2C0_SDA_PORT		gpioPortC
#define I2C0_SDA_pin		11

#define I2C_ENABLE_PORT		gpioPortD
#define I2C_ENABLE_pin		15

//***********************************************************************************
// function prototypes
//***********************************************************************************

/*
 * this function initializes the clock, SDA / SCL lines, and i2c bus
 */
void i2cInit(void);

/*
 * turns on the necessary pins to start I2C comms
 */
void i2cLoadPowerOn(void);

/*
 * turns off the i2c perif pins / Load Power Management Off
 */
void i2cLoadPowerOff(void);

/*
 * this is the interrupt service routine for i2c
 */
void I2Cn_IRQHandler(void);

/*
 * enables sensors, waits for POR length of time, and allows to sleep
 */
void tempSenseEnable(void);

/*
 * allows for the writing of a single byte of data to the i2c bus, specifically
 * for the TSL2561
 * para: slave_addr = device bus address
 * para: reg_addr = address of the register you would like to access on sensor
 * para: cmd = which command you wish to execute on sensor
 * para: data = register setting to be set, data to be sent
 */
void myBG_i2cWrite(uint8_t slave_addr, uint8_t reg_addr, uint8_t cmd, uint8_t data);

/*
 * allows for the writing of a two bytes of data to the i2c bus, specifically
 * for the TSL2561
 * para: slave_addr = device bus address
 * para: reg_addr = address of the register you would like to access on sensor
 * para: cmd = which command you wish to execute on sensor
 * para: dataHigh = high byte of data to be sent
 * para: dataLow = low byte of data to be sent
 */
void myBG_i2cWriteWORD(uint8_t slave_addr, uint8_t reg_addr, uint8_t cmd, uint8_t dataHigh, uint8_t dataLow);

/*
 * Allows for the reading of a single byte from the i2c bus, specifically
 * for the TSL2561
 * para: slave_addr = device bus address
 * para: reg_addr = address of the register you would like to access on sensor
 * para: cmd = which command you wish to execute on sensor
 */
uint8_t myBG_i2cRead(uint8_t slave_addr, uint8_t reg_addr, uint8_t cmd);

#endif /*myBG_i2cdriver_H_ */
















