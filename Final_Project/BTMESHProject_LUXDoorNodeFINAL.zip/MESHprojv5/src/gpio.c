/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 11-09-2018
 *
 * FILE: gpio.c
 *
 * DESCRIPTION:  function definitions for the GPIO initialization
 *
 * PLEASE NOTE!: This file was provided by Professor Keith Graham and used and
 * modified with permission for this class.
 */


//***********************************************************************************
// Include files
//***********************************************************************************
#include "src/gpio.h"

//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// functions
//***********************************************************************************
void gpio_init(void){
	CMU_ClockEnable(cmuClock_GPIO, true);
	NVIC_EnableIRQ(GPIO_EVEN_IRQn);

	// Set LED ports to be standard output drive with default off (cleared)
	GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);
	GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthWeakAlternateWeak);

	GPIO_PinModeSet(LED1_port, LED1_pin, gpioModePushPull, LED1_default);
	GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthWeakAlternateWeak);
	//GPIO_DriveModeSet(LED0_port, gpioDriveStrengthWeakAlternateWeak);

	GPIO_PinModeSet(PB0_PORT, PB0_PIN, gpioModeInputPull, PB0_DEFAULT);
	GPIO_PinModeSet(PB1_PORT, PB1_PIN, gpioModeInputPull, PB1_DEFAULT);

	GPIO->IFC = 0x00;				//reset all GPIO interrupts that may have been set
}
