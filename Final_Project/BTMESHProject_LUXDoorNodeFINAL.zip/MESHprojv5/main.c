/***********************************************************************************************//**
 * \file   main.c
 * \brief  Silicon Labs BT Mesh Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko BT Mesh C application.
 * The application starts unprovisioned Beaconing after boot
 ***************************************************************************************************
 * <b> (C) Copyright 2017 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/
/******************************
 * Class: ECEN 5823-011, Internet of Things Embedded Firmware, Fall 2018
 * Professor:  Keith Graham
 * Author: Andrew Kuklinski
 * Created On: 11-09-2018
 *
 * FILE: main.c
 *
 * DESCRIPTION:  main function for Bluetooth Mesh project
 */

#include "src/main.h"
#include "src/gpio.h"
#include "src/LUX_sensor.h"
//#include "src/event_fxns.h"


/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/

// bluetooth stack heap
#define MAX_CONNECTIONS 2

uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS) + BTMESH_HEAP_SIZE + 1760];

// Bluetooth advertisement set configuration
//
// At minimum the following is required:
// * One advertisement set for Bluetooth LE stack (handle number 0)
// * One advertisement set for Mesh data (handle number 1)
// * One advertisement set for Mesh unprovisioned beacons (handle number 2)
// * One advertisement set for Mesh unprovisioned URI (handle number 3)
// * N advertisement sets for Mesh GATT service advertisements
// (one for each network key, handle numbers 4 .. N+3)
//
#define MAX_ADVERTISERS (4 + MESH_CFG_MAX_NETKEYS)

// bluetooth stack configuration
extern const struct bg_gattdb_def bg_gattdb_data;

// Flag for indicating DFU Reset must be performed
uint8_t boot_to_dfu = 0;

const gecko_configuration_t config =
{
  .bluetooth.max_connections = MAX_CONNECTIONS,
  .bluetooth.max_advertisers = MAX_ADVERTISERS,
  .bluetooth.heap = bluetooth_stack_heap,
  .bluetooth.heap_size = sizeof(bluetooth_stack_heap) - BTMESH_HEAP_SIZE,
  .bluetooth.sleep_clock_accuracy = 100,
  .gattdb = &bg_gattdb_data,
  .btmesh_heap_size = BTMESH_HEAP_SIZE,
#if (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
  .pa.config_enable = 1, // Enable high power PA
  .pa.input = GECKO_RADIO_PA_INPUT_VBAT, // Configure PA input to VBAT
#endif // (HAL_PA_ENABLE) && defined(FEATURE_PA_HIGH_POWER)
  .max_timers = 16,
};

static void handle_gecko_event(uint32_t evt_id, struct gecko_cmd_packet *evt);
void mesh_native_bgapi_init(void);
bool mesh_bgapi_listener(struct gecko_cmd_packet *evt);

/*callback function for client request event
 * used to receive messages from a client to request a state change
 * this opens the door and starts a timer to close it
 */
static void client_request_callback(uint16_t model_id,
       uint16_t element_index,
       uint16_t client_addr,
       uint16_t server_addr,
       uint16_t appkey_index,
       const struct mesh_generic_request *request,
       uint32_t transition_ms,
       uint16_t delay_ms,
       uint8_t request_flags)
{
	if(request->level == 0x7fff)
	{
		printf_counter++;
		printf("[%d] : DOOR OPENED!!\n",printf_counter);
		LCD_write("DOOR OPENED!!", LCD_ROW_ACTION);
		GPIO_PinOutSet(LED0_port, LED0_pin);
		gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(DOOR_OPEN),TIMER_ID_DOOR_OPERATION,1);
		gecko_cmd_flash_ps_save(PERSIS_DATA_BASE_ADDR, (uint8_t)sizeof(persist_data), (uint8_t*)&my_stored_data);
	}
}

/*
 * callback functions for client request, not used in this implementation
 */
static void state_change_callback(uint16_t model_id,
       uint16_t element_index,
       const struct mesh_generic_state *current,
       const struct mesh_generic_state *target,
       uint32_t remaining_ms)
{
	//printf("just entered state_change_callback function....\n");
}

/**
 *  this function is called to initiate factory reset. Factory reset may be initiated
 *  by keeping one of the WSTK pushbuttons pressed during reboot. Factory reset is also
 *  performed if it is requested by the provisioner (event gecko_evt_mesh_node_reset_id)
 *
 *  THIS FUNCTION WAS TAKEN FROM THE SILABS LIGHT EXAMPLE AND UTITILIZED AND MODIFIED HERE
 */
void initiate_factory_reset(void)
{
	printf_counter++;
	printf("[%d] : Factory Reset Started\n",printf_counter);
	LCD_write("****FACTORY RESET****", LCD_ROW_ACTION);

	/* if connection is open then close it before rebooting */
	if (conn_handle != 0xFF)
	{
	gecko_cmd_le_connection_close(conn_handle);
	}

	/* perform a factory reset by erasing PS storage. This removes all the keys and other settings
	 that have been configured for this node */
	gecko_cmd_flash_ps_erase_all();
	gecko_cmd_hardware_set_soft_timer(2*32768, TIMER_ID_FACTORY_RESET, 1);
}

//state struct for the generic level model
//struct mesh_generic_state current_state_generic_level;

int main()
{
	//initializing global variables
	uint8_t sensor_check_value = 0;
	_primary_elem_index = 0;
	conn_handle = 0xFF;
	printf_counter = 0;

	my_stored_data.num_door_open = 0;			//persistent data
	my_stored_data.lux_value = 0;				//persistent data

	initMcu();									// Initialize device
	initBoard();								// Initialize board
	initApp();									// Initialize application
	gpio_init();								//initialize GPIO
	i2cInit();									//initialize i2c bus
	RETARGET_SerialInit();						//used to push UART printf data to screen
	RETARGET_SerialCrLf(true);					//used to push UART printf data to screen

	gecko_stack_init(&config);
	gecko_bgapi_class_dfu_init();
	gecko_bgapi_class_system_init();
	gecko_bgapi_class_le_gap_init();
	gecko_bgapi_class_le_connection_init();
	gecko_bgapi_class_gatt_init();
	gecko_bgapi_class_gatt_server_init();
	gecko_bgapi_class_endpoint_init();
	gecko_bgapi_class_hardware_init();
	gecko_bgapi_class_flash_init();
	gecko_bgapi_class_test_init();
	gecko_bgapi_class_sm_init();
	mesh_native_bgapi_init();
	gecko_initCoexHAL();

	gecko_bgapi_class_mesh_node_init();
	gecko_bgapi_class_mesh_generic_server_init();
	gecko_bgapi_class_mesh_friend_init();

	gecko_bgapi_class_mesh_proxy_init();
	gecko_bgapi_class_mesh_proxy_server_init();

	LCD_init("MESH LUX NODE (ak)");
	LCD_write("",LCD_ROW_CONNECTION);
	printf("\n\n\n\n\n\n\n");
	printf("*************ECEN5823 Final Project**************\n");
	printf("***************Bluetooth Mesh Node***************\n");
	printf("*******************LUX Sensor********************\n");
	printf("************Author: Andrew Kuklinski*************\n");
	printf_counter++;
	printf("[%d] : Board Initialization Complete\n",printf_counter);


	current_state_generic_level.kind = mesh_generic_state_level;
	current_state_generic_level.level.level = 0x00;

	//checks operation of sensor
	sensor_check_value = LUX_sensor_check();
	if(sensor_check_value == 0)
	{
		printf_counter++;
		printf("[%d] : Sensor Communication SUCCESS\n",printf_counter);
	}
	else
	{
		printf_counter++;
		printf("[%d] : Sensor Error...\n",printf_counter);
	}
	LUX_sensor_init();					//initialize LUX sensor
	display_LUX_settings();


	while (1)
	{
		struct gecko_cmd_packet *evt = gecko_wait_event();
		bool pass = mesh_bgapi_listener(evt);
		if (pass)
		{
		  handle_gecko_event(BGLIB_MSG_ID(evt->header), evt);
		}
	}
}

static void handle_gecko_event(uint32_t evt_id, struct gecko_cmd_packet *evt)
{
  switch (evt_id) {

    case gecko_evt_system_boot_id:
        // check pushbutton state at startup. If either PB0 or PB1 is held down then do factory reset
        if (GPIO_PinInGet(PB0_PORT, PB0_PIN) == 0 || GPIO_PinInGet(PB1_PORT, PB1_PIN) == 0)
        {
        	initiate_factory_reset();
        }
        else
        {
			struct gecko_msg_system_get_bt_address_rsp_t *connection_addr_gecko;
			connection_addr_gecko = gecko_cmd_system_get_bt_address();				//creating event to get BT address.

			sprintf(LCD_array_store, "%02x:%02x:%02x:%02x:%02x:%02x",
					connection_addr_gecko->address.addr[5],connection_addr_gecko->address.addr[4],
					connection_addr_gecko->address.addr[3],connection_addr_gecko->address.addr[2],
					connection_addr_gecko->address.addr[1],connection_addr_gecko->address.addr[0]);
			LCD_write("BT ADDR:", LCD_ROW_BTADDR1);
			LCD_write(LCD_array_store, LCD_ROW_BTADDR2);
			LCD_write("No Friend",LCD_ROW_CLIENTADDR);

			//indicates that Out-Of-Band authentication is required
        	result = gecko_cmd_mesh_node_init_oob(PUBLIC_KEY_NONE,AUTH_METH_OUTPUT_OOB,OUTPUT_NUMERIC,
        			OUT_SIZE_2,INPUT_NONE,INPUT_SIZE_NA,DATA_LOC_NONE)->result;
        	if(result)
    		{
        		printf_counter++;
    			printf("[%d] : Mesh Node Initialization Failed. Error 0x%x\n",printf_counter, result);
    		}
        }
        //read persistent data, output current persistent data that was stored
    	struct gecko_msg_flash_ps_load_rsp_t *ps_load_data;
    	ps_load_data = gecko_cmd_flash_ps_load(PERSIS_DATA_BASE_ADDR);
    	if(!(ps_load_data->result))
    	{
    		memcpy(&my_stored_data,ps_load_data->value.data,ps_load_data->value.len);
    	}
    	else
    	{
    		printf_counter++;
    		printf("[%d] : Persistent Data Set to Defaults\n",printf_counter);
    	}
    	printf_counter++;
    	printf("[%d] : num_door_open: %d || lux_value: %f\n",printf_counter,
    			my_stored_data.num_door_open,my_stored_data.lux_value);
		sprintf(LCD_array_store,"Provisioned : 0x%x",evt->data.evt_mesh_node_provisioned.address);
		LCD_write(LCD_array_store,LCD_ROW_CONNECTION);
      break;
/**************************************************************************************************
 * CODE BELOW IS RELATED TO PROVISIONING
 **************************************************************************************************/
    case gecko_evt_mesh_node_initialized_id:
		mesh_lib_init(malloc,free,NUM_MODELS_AVAILABLE);
		gecko_cmd_mesh_generic_server_init();

		//first function is for client request callback, second is for state change request
		mesh_lib_generic_server_register_handler(MESH_GENERIC_LEVEL_SERVER_MODEL_ID,0,
				client_request_callback, state_change_callback);

		// The Node is now initialized, start unprovisioned Beaconing using PB-Adv Bearer if not already provisisioned
		printf_counter++;
		printf("[%d] : Node INIT Complete\n", printf_counter);
		//checking to see if board is already provisioned
		if((evt->data.evt_mesh_node_initialized.provisioned))
		{
			printf_counter++;
			printf("[%d] : Node Provisioned, status %d\n",
					printf_counter, evt->data.evt_mesh_node_initialized.provisioned);
			//timer for getting LUX value after a set amount of time
			gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(LUX_GET_INTERVAL),TIMER_ID_LUX_VALUE_GET,1);
	    	result = gecko_cmd_mesh_friend_init()->result;				//since already provisioned, need to advert friend connectablitity
	    	if(result)
	    	{
	    		printf_counter++;
	    		printf("[%d] : Friend node initialization failed\n",printf_counter);
	    	}
		}
		else				//otherwise advert to be provisioned
		{
			printf_counter++;
			printf("[%d] : Beaconing Started...\n",printf_counter);
			gecko_cmd_mesh_node_start_unprov_beaconing(BEARER_BOTH);
			LCD_write("Beaconing...",LCD_ROW_CONNECTION);
		}
		break;

    case gecko_evt_mesh_node_provisioning_started_id:
		//indicates that provisioning has started
    	printf_counter++;
		printf("[%d] : Provisioning started...\n",printf_counter);
		LCD_write("Provisioning...",LCD_ROW_CONNECTION);
		break;

    case gecko_evt_mesh_node_display_output_oob_id:				//OOB authentication code is displayed here
    	printf_counter++;
    	struct gecko_msg_mesh_node_display_output_oob_evt_t *OOB_code =
    			(struct gecko_msg_mesh_node_display_output_oob_evt_t *)&(evt->data);

    	printf("[%d] : Provisioning Code :: %d\n",printf_counter, OOB_code->data.data[15]);
		sprintf(LCD_array_store, "OOB Code: %d",OOB_code->data.data[15]);
		LCD_write(LCD_array_store, LCD_ROW_ACTION);
    	break;

    case gecko_evt_mesh_node_provisioned_id:				//node provisioned and authenticated and advert friendship

    	LCD_write("",LCD_ROW_ACTION);
    	result = gecko_cmd_mesh_friend_init()->result;
    	if(result)
    	{
    		printf_counter++;
    		printf("[%d] : Friend node initialization failed\n",printf_counter);
    	}
    	else
    	{
    		printf_counter++;
        	printf("[%d] : Provisioning complete! Mesh Addr: 0x%x\n",printf_counter, evt->data.evt_mesh_node_provisioned.address);
        	sprintf(LCD_array_store,"Provisioned : 0x%x",evt->data.evt_mesh_node_provisioned.address);
        	LCD_write(LCD_array_store,LCD_ROW_CONNECTION);
        	gecko_cmd_hardware_set_soft_timer(TIMER_MS_2_TIMERTICK(LUX_GET_INTERVAL),TIMER_ID_LUX_VALUE_GET,1);
    	}
    	break;

    case gecko_evt_mesh_node_provisioning_failed_id:			//catches provisioning failures
    	printf_counter++;
    	printf("[%d] : Provisioning Failed: 0x%x\n",printf_counter, evt->data.evt_mesh_node_provisioning_failed.result);
		LCD_write("Failed. Reset Now",LCD_ROW_CONNECTION);
    	break;


/****************************************************************************************************
 * CODE BELOW RALTAED TO CONFIGURATION OF NODE
 ****************************************************************************************************/

    case gecko_evt_mesh_node_key_added_id:
    	if(evt->data.evt_mesh_node_key_added.type)
    	{
    		printf_counter++;
    		printf("[%d] : New Application Key Added\n", printf_counter);
    	}
    	else
    	{
    		printf_counter++;
    		printf("[%d] : New Network Key Added\n", printf_counter);
    	}
    	break;

    case gecko_evt_mesh_node_model_config_changed_id:
    	printf_counter++;
    	printf("[%d] : Model Configuration Changed\n",printf_counter);
    	break;

    case gecko_evt_le_connection_opened_id:

    	printf_counter++;
		printf("[%d] : Connection Opened\n",printf_counter);
		conn_handle = evt->data.evt_le_connection_opened.connection;
		break;

    case gecko_evt_le_connection_closed_id:
      //Check if need to boot to dfu mode
      if (boot_to_dfu) {
        //Enter to DFU OTA mode
        gecko_cmd_system_reset(2);
      }
      printf_counter++;
    	printf("[%d] : Connection Closed...\n",printf_counter);
      break;

/******************************************************************************************************
* CODE BELOW IS RELATED TO ESTABLISHING A FRIENDSHIP
*******************************************************************************************************/

    case gecko_evt_mesh_friend_friendship_established_id:
    	printf_counter++;
      	printf("[%d] : Friendship Established... LPN ADDR: 0x%x\n",printf_counter, evt->data.evt_mesh_lpn_friendship_established.friend_address);
      	sprintf(LCD_array_store, "Friendship Addr: 0x%x", evt->data.evt_mesh_lpn_friendship_established.friend_address);
      	LCD_write(LCD_array_store,LCD_ROW_CLIENTADDR);
      	break;

    case gecko_evt_mesh_friend_friendship_terminated_id:
    	printf_counter++;
      	printf("[%d] : Friendship Terminated: 0x%x\n", printf_counter, evt->data.evt_mesh_friend_friendship_terminated.reason);
      	LCD_write("No Friend",LCD_ROW_CLIENTADDR);
      	break;


/**********************************************************************************************************
 * CODE BELOW RELATED TO RX/TX MESSAGES TO/FROM NETWORK
 **********************************************************************************************************/

      	//this event is called when a request is received from a client for a state change (door open from fingerprint)
    case gecko_evt_mesh_generic_server_client_request_id:
    	printf_counter++;
    	printf("[%d] : Generic Server Client Request\n",printf_counter);
    	my_stored_data.num_door_open++;									//update persistent data vars
    	my_stored_data.lux_value = current_lux_value;					//update persistent data vars
    	mesh_lib_generic_server_event_handler(evt);						//make call to registered callback
    	break;

    case gecko_evt_system_external_signal_id:							//no external events should be occurring
    	printf("\n\n");
    	uint32_t which_event_happened = evt->data.evt_system_external_signal.extsignals;
    	printf_counter++;
    	printf("[%d] : External Event Occurred? Event: %lu\n",printf_counter, which_event_happened);
    	break;

	case gecko_evt_mesh_generic_server_state_changed_id:
		printf_counter++;
		printf("[%d] : Generic Server State Just Changed...\n",printf_counter);
		break;

/***************************************************************************************
 * CODE BELOW REALTED TO SETTING SOFT TIMERS
  **************************************************************************************/
    case gecko_evt_hardware_soft_timer_id:
    	//_primary_elem_index = 0;
    	switch(evt->data.evt_hardware_soft_timer.handle)
    	{

    		case TIMER_ID_LUX_VALUE_GET:					//Retrieves current LUX value and publishes to the newtork accordingly
    			event_soft_timer_GETLUXVALUE();
    			break;

    		case TIMER_ID_DOOR_OPERATION:						//after client request received, keep door open for set amount of time
    			printf_counter++;
    			printf("[%d] : DOOR CLOSED\n",printf_counter);
    			LCD_write("", LCD_ROW_ACTION);
    			GPIO_PinOutClear(LED0_port, LED0_pin);
    			break;
    		case TIMER_ID_FACTORY_RESET:						//reset board after amount of time when requested
    			LCD_write("", LCD_ROW_NAME);
    			gecko_cmd_system_reset(0);
    			break;
    		case TIMER_ID_DISPLAY_ALARM_LCD:					//keep indication on LCD of message publish for set amount of time
    			LCD_write("",LCD_ROW_9);
    			break;
    	}

    	break;


/*****************************************************************************************
*  CODE BELOW THIS LINE IS REALTED TO DFU OPERATIONS AND IS NOT USED
******************************************************************************************/

    case gecko_evt_dfu_boot_id:
      //gecko_cmd_le_gap_set_advertising_timing(0, 1000*adv_interval_ms/625, 1000*adv_interval_ms/625, 0, 0);
      gecko_cmd_le_gap_set_mode(2, 2);
      break;

    case gecko_evt_gatt_server_user_write_request_id:
      if (evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ota_control) {
        /* Set flag to enter to OTA mode */
        boot_to_dfu = 1;
        /* Send response to Write Request */
        gecko_cmd_gatt_server_send_user_write_response(
          evt->data.evt_gatt_server_user_write_request.connection,
          gattdb_ota_control,
          bg_err_success);

        /* Close connection to enter to DFU OTA mode */
        gecko_cmd_le_connection_close(evt->data.evt_gatt_server_user_write_request.connection);
      }
      break;

    default:
      break;
  }
}
